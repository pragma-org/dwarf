# DWARF measurement report

Scenario: client-example-plutus-vm-amaru-portable-20260918
Duration: 709.49939756 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 284 | 51989.031690140844 | 833.5 | 1981.0 | 2993563.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 284 | 1074.1161971830986 | 838.0 | 2414.0 | 3287.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 284 | 381108.6971830986 | 2883.0 | 11661.0 | 21993962.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 5 | 2980.4 | 2634.0 | 5719.0 | 5719.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | available | 121 | 220.31404958677686 | 208.0 | 349.0 | 400.0 | us |
| virtual_machine_acquire_arena | available | 61 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 61 | 3.6885245901639343 | 4.0 | 5.0 | 6.0 | us |
| virtual_machine_build_program | available | 61 | 35.98360655737705 | 33.0 | 50.0 | 58.0 | us |
| virtual_machine_evaluate | available | 61 | 22.278688524590162 | 21.0 | 33.0 | 34.0 | us |
| block_prepare | available | 283 | 6.151943462897527 | 6.0 | 9.0 | 15.0 | us |
| block_application | available | 278 | 136.10312589928057 | 128.762 | 185.966 | 302.79 | us |
| epoch_transition | available | 3 | 10635.0 | 11081.0 | 12420.0 | 12420.0 | us |
| keepalive_round_trip | available | 24 | 530.2083333333334 | 480.0 | 1003.0 | 1212.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 340 | 0.35217572618717624 | 0.46945247587330324 | 0.9607290593903574 | 3.3660051162202858 | % |
| cpu_time_seconds | available | 341 | — | — | — | — | s |
| rss_bytes | available | 341 | 80749012.457478 | 81002496.0 | 81543168.0 | 81645568.0 | bytes |
| network_rx_bytes | available | 341 | — | — | — | — | bytes |
| network_tx_bytes | available | 341 | — | — | — | — | bytes |
| disk_read_bytes | available | 341 | — | — | — | — | bytes |
| disk_write_bytes | available | 341 | — | — | — | — | bytes |
| fd_count | available | 341 | 28.14956011730205 | 28.0 | 29.0 | 29.0 | fds |
| threads | available | 341 | 28.0 | 28.0 | 28.0 | 28.0 | threads |
| container_memory_bytes | available | 341 | 58118446.6744868 | 58342768.0 | 58898513.0 | 59013857.0 | bytes |
| container_tasks | available | 341 | 28.0 | 28.0 | 28.0 | 28.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 1 | — | — | — | — | operations |
| attempt_latency | available | 63 | 3831689.529857143 | 3114040.135 | 8771919.33 | 13713461.192 | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | available | 60 | 3989858.46015 | 3141204.306 | 8771919.33 | 13713461.192 | us |
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_decode | available | 2258 | 1.3195642161204606 | 0.901 | 5.07 | 6.252 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 2258 | 1.676292294065545 | 1.112 | 6.342 | 7.745 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | unavailable | 0 | — | — | — | — | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | unavailable | 0 | — | — | — | — | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | unavailable | 0 | — | — | — | — | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| handler | available | 1399 | 25.171723373838457 | 20.76 | 57.43 | 86.716 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 283 | 2.673505300353357 | 2.545 | 4.037 | 5.16 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 1399 | 0.8005718370264474 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 1399 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | unavailable | 0 | — | — | — | — | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | unavailable | 0 | — | — | — | — | us |
| body_to_terminal | unavailable | 0 | — | — | — | — | us |
| amaru-patched-txsubmission-residence.pending_depth | unavailable | 0 | — | — | — | — | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | unavailable | 0 | — | — | — | — | transactions |
| unacked_depth | unavailable | 0 | — | — | — | — | transactions |
| blocking_residence | unavailable | 0 | — | — | — | — | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
