# Plutus V2 evaluator conformance

Cost model: `sha256:675a27a3c1f2f9b32954c67c1f0ad21479713eef5513386638d78e05f5e277cc` (175 ordered parameters).

Raw nanoseconds are retained. Human-facing microseconds preserve the fractional part.

- amaru accepted: n=30, p50=59.584 us, p95=96.565 us
- amaru rejected: n=30, p50=57.870 us, p95=91.555 us
- cardano-node accepted: n=30, p50=9.087 us, p95=19.187 us
- cardano-node rejected: n=30, p50=38.824 us, p95=49.665 us
