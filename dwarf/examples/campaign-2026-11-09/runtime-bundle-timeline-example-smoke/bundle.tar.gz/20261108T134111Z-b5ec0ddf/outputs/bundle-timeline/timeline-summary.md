# Bundle Timeline

- Input bundles: 7
- Events included: 7
- Signature count: 7
- Time window start: 2026-11-08T13:37:29.336932Z
- Time window end: 2026-11-08T13:41:06.704116Z

## Signatures

| signature_id | scenario | exit | sightings | first bundle | last bundle |
| --- | --- | --- | ---: | --- | --- |
| af55d2b14ca5 | runtime-substrate-txsubmission-unexpected-body-mixed-amaru | error | 1 | 20261108T133729Z-31786d1e | 20261108T133729Z-31786d1e |
| edea40cae035 | amaru-cbor-auxiliary-data-fuzz-structured | pass | 1 | 20261108T134035Z-0bf053cf | 20261108T134035Z-0bf053cf |
| 0a806a8fa771 | cardano-amaru-cbor-dataset-auxiliary-data-differential | fail | 1 | 20261108T134046Z-01ee7e60 | 20261108T134046Z-01ee7e60 |
| 18d726fa0396 | cardano-node-cov-applyblock-aflpp-smoke | pass | 1 | 20261108T134052Z-21f52a02 | 20261108T134052Z-21f52a02 |
| 3aa00f1d7794 | runtime-bundle-chain-verify-example-smoke | fail | 1 | 20261108T134056Z-5ce93a4f | 20261108T134056Z-5ce93a4f |
| a655237ca290 | runtime-bundle-export-sarif-example-smoke | pass | 1 | 20261108T134101Z-542886b3 | 20261108T134101Z-542886b3 |
| 40a1919de543 | runtime-bundle-summary-compose-example-smoke | fail | 1 | 20261108T134106Z-c36aee71 | 20261108T134106Z-c36aee71 |

## Events

| timestamp | bundle | signature |
| --- | --- | --- |
| 2026-11-08T13:37:29.336932Z | 20261108T133729Z-31786d1e | af55d2b14ca5 |
| 2026-11-08T13:40:35.832536Z | 20261108T134035Z-0bf053cf | edea40cae035 |
| 2026-11-08T13:40:46.859069Z | 20261108T134046Z-01ee7e60 | 0a806a8fa771 |
| 2026-11-08T13:40:52.062845Z | 20261108T134052Z-21f52a02 | 18d726fa0396 |
| 2026-11-08T13:40:56.881387Z | 20261108T134056Z-5ce93a4f | 3aa00f1d7794 |
| 2026-11-08T13:41:01.674495Z | 20261108T134101Z-542886b3 | a655237ca290 |
| 2026-11-08T13:41:06.704116Z | 20261108T134106Z-c36aee71 | 40a1919de543 |
