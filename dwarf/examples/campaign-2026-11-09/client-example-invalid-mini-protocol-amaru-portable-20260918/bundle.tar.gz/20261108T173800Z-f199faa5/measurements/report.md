# DWARF measurement report

Scenario: client-example-invalid-mini-protocol-amaru-portable-20260918
Duration: 332.480905421 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 137 | 110549.78102189781 | 1164.0 | 3218.0 | 4993887.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 137 | 1382.912408759124 | 944.0 | 3470.0 | 5348.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 137 | 699489.1824817518 | 3543.0 | 52614.0 | 26495579.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 5 | 3093.6 | 3323.0 | 4064.0 | 4064.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | unavailable | 0 | — | — | — | — | us |
  - transfer_validation: no completed stock telemetry span was exported for transaction-validation
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 136 | 6.551470588235294 | 5.0 | 8.0 | 24.0 | us |
| block_application | available | 131 | 1294.0239694656486 | 180.616 | 6565.775 | 9144.301 | us |
| epoch_transition | available | 2 | 25496.0 | 25496.0 | 33723.0 | 33723.0 | us |
| keepalive_round_trip | available | 11 | 621.4545454545455 | 612.0 | 757.0 | 757.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 159 | 0.46943594106365594 | 0.4782489144079638 | 0.9583159596699897 | 2.3936284980330704 | % |
| cpu_time_seconds | available | 160 | — | — | — | — | s |
| rss_bytes | available | 160 | 103715865.6 | 103714816.0 | 104583168.0 | 104624128.0 | bytes |
| network_rx_bytes | available | 160 | — | — | — | — | bytes |
| network_tx_bytes | available | 160 | — | — | — | — | bytes |
| disk_read_bytes | available | 160 | — | — | — | — | bytes |
| disk_write_bytes | available | 160 | — | — | — | — | bytes |
| fd_count | available | 160 | 27.81875 | 28.0 | 29.0 | 29.0 | fds |
| threads | available | 160 | 28.0 | 28.0 | 28.0 | 28.0 | threads |
| container_memory_bytes | available | 160 | 104932376.1375 | 104857600.0 | 105696460.0 | 106011033.0 | bytes |
| container_tasks | available | 160 | 28.0 | 28.0 | 28.0 | 28.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_decode | available | 1278 | 2.2322511737089203 | 1.3075 | 5.11 | 6.382 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 1278 | 2.6123646322378717 | 1.528 | 6.493 | 8.115 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | available | 200 | 1.75601 | 1.593 | 2.986 | 4.599 | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | available | 200 | 2.252065 | 2.109 | 3.687 | 4.378 | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | available | 100 | 0.7836799999999999 | 0.691 | 1.403 | 1.914 | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| handler | available | 668 | 29.351738023952095 | 22.0825 | 66.117 | 116.022 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 136 | 2.5365220588235293 | 2.495 | 3.727 | 7.294 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 668 | 0.8008982035928144 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 668 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | unavailable | 0 | — | — | — | — | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | unavailable | 0 | — | — | — | — | us |
| body_to_terminal | unavailable | 0 | — | — | — | — | us |
| amaru-patched-txsubmission-residence.pending_depth | unavailable | 0 | — | — | — | — | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | unavailable | 0 | — | — | — | — | transactions |
| unacked_depth | unavailable | 0 | — | — | — | — | transactions |
| blocking_residence | unavailable | 0 | — | — | — | — | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
