# DWARF measurement report

Scenario: client-example-block-application-amaru-portable-20260918
Duration: 252.986261896 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 118 | 47926.73728813559 | 1198.5 | 2761.0 | 1998425.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 118 | 1186.0169491525423 | 880.0 | 2955.0 | 4803.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 118 | 247042.13559322033 | 3655.0 | 22513.0 | 11995889.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 5 | 1860.4 | 1558.0 | 3080.0 | 3080.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | unavailable | 0 | — | — | — | — | us |
  - transfer_validation: no completed stock telemetry span was exported for transaction-validation
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 117 | 5.803418803418803 | 5.0 | 8.0 | 23.0 | us |
| block_application | available | 112 | 887.3158035714285 | 167.546 | 6195.951 | 8489.433 | us |
| epoch_transition | available | 2 | 19216.0 | 19216.0 | 19934.0 | 19934.0 | us |
| keepalive_round_trip | available | 8 | 513.125 | 472.5 | 838.0 | 838.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 121 | 0.4149423314846524 | 0.47779173806951575 | 0.9577182382740671 | 1.9125313994177737 | % |
| cpu_time_seconds | available | 122 | — | — | — | — | s |
| rss_bytes | available | 122 | 102483833.70491803 | 102481920.0 | 102793216.0 | 102813696.0 | bytes |
| network_rx_bytes | available | 122 | — | — | — | — | bytes |
| network_tx_bytes | available | 122 | — | — | — | — | bytes |
| disk_read_bytes | available | 122 | — | — | — | — | bytes |
| disk_write_bytes | available | 122 | — | — | — | — | bytes |
| fd_count | available | 122 | 29.516393442622952 | 30.0 | 30.0 | 30.0 | fds |
| threads | available | 122 | 28.0 | 28.0 | 28.0 | 28.0 | threads |
| container_memory_bytes | available | 122 | 103716026.8852459 | 103698923.0 | 104039710.0 | 104092139.0 | bytes |
| container_tasks | available | 122 | 28.0 | 28.0 | 28.0 | 28.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_decode | available | 930 | 2.467620430107527 | 1.042 | 5.18 | 6.383 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 930 | 2.8577827956989243 | 1.2075 | 6.522 | 7.745 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | unavailable | 0 | — | — | — | — | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | unavailable | 0 | — | — | — | — | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | unavailable | 0 | — | — | — | — | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| handler | available | 581 | 26.348722891566265 | 21.421 | 62.049 | 104.48 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 117 | 2.4015384615384616 | 2.345 | 3.617 | 4.038 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 581 | 0.8003442340791739 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 581 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | unavailable | 0 | — | — | — | — | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | unavailable | 0 | — | — | — | — | us |
| body_to_terminal | unavailable | 0 | — | — | — | — | us |
| amaru-patched-txsubmission-residence.pending_depth | unavailable | 0 | — | — | — | — | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | unavailable | 0 | — | — | — | — | transactions |
| unacked_depth | unavailable | 0 | — | — | — | — | transactions |
| blocking_residence | unavailable | 0 | — | — | — | — | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
