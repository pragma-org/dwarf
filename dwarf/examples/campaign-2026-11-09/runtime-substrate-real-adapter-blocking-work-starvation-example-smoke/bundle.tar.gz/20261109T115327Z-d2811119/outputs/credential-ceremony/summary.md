# Credential Ceremony

- Keys generated: 1
- KES period window: 1
- VRF pubkey hash: `75ec5dda5ba85c4d3c7686320f73ffe3cbc71a5ab2ae955a7b3024a42af9dc47`
- Stake address hash: `00cecca5b3135bb0c5b5a25b14dbef43dcc5516e08e6df2c1060efc8d614e69c`
- Deterministic seed used: `blocking-work-real-adapter`
