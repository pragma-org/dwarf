# Credential Ceremony

- Keys generated: 1
- KES period window: 1
- VRF pubkey hash: `d2a909808fbe359638b66ae096c250d000949ee1f57aace0ab1518e5133dacaf`
- Stake address hash: `45351bc1aced21762797199fc568f9f76912c692db6f99843cd30c44964bc19e`
- Deterministic seed used: `runtime-starvation-real-adapter`
