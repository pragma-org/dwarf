# DWARF measurement report

Scenario: client-example-simple-transfer-amaru-portable-20260918
Duration: 228.119410231 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 85 | 1271.4352941176471 | 1116.0 | 2184.0 | 4933.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 85 | 1387.2235294117647 | 1213.0 | 2844.0 | 4457.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 85 | 6407.823529411765 | 3907.0 | 12707.0 | 81579.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 2 | 2759.5 | 2759.5 | 3301.0 | 3301.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | available | 32 | 221.90625 | 185.5 | 529.0 | 976.0 | us |
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 85 | 9.905882352941177 | 6.0 | 19.0 | 197.0 | us |
| block_application | available | 83 | 988.9157951807229 | 216.434 | 1363.73 | 34437.506 | us |
| epoch_transition | available | 1 | 11463.0 | 11463.0 | 11463.0 | 11463.0 | us |
| keepalive_round_trip | available | 7 | 514.4285714285714 | 502.0 | 734.0 | 734.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 114 | 0.3885058778701777 | 0.0 | 0.9997699873701421 | 2.4952099632801064 | % |
| cpu_time_seconds | available | 115 | — | — | — | — | s |
| rss_bytes | available | 115 | 105844557.91304348 | 105889792.0 | 106209280.0 | 106270720.0 | bytes |
| network_rx_bytes | available | 115 | — | — | — | — | bytes |
| network_tx_bytes | available | 115 | — | — | — | — | bytes |
| disk_read_bytes | available | 115 | — | — | — | — | bytes |
| disk_write_bytes | available | 115 | — | — | — | — | bytes |
| fd_count | available | 115 | 29.495652173913044 | 29.0 | 30.0 | 30.0 | fds |
| threads | available | 115 | 28.0 | 28.0 | 28.0 | 28.0 | threads |
| container_memory_bytes | available | 115 | 106374843.45217392 | 106430464.0 | 106745036.0 | 106745036.0 | bytes |
| container_tasks | available | 115 | 28.0 | 28.0 | 28.0 | 28.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 1 | — | — | — | — | operations |
| attempt_latency | available | 35 | 3315389.2452285714 | 2674998.657 | 7579066.583 | 9937038.341 | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | available | 30 | 3061006.778833333 | 2549424.242 | 6867945.687 | 9237686.33 | us |
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_decode | available | 680 | 1.4849764705882353 | 1.142 | 5.19 | 6.312 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 680 | 1.8967573529411765 | 1.3425 | 6.503 | 7.805 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | unavailable | 0 | — | — | — | — | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | unavailable | 0 | — | — | — | — | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | unavailable | 0 | — | — | — | — | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| handler | available | 425 | 31.324242352941177 | 23.164 | 72.398 | 202.717 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 85 | 3.033188235294118 | 2.815 | 4.829 | 8.275 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 425 | 0.8 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 425 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | unavailable | 0 | — | — | — | — | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | unavailable | 0 | — | — | — | — | us |
| body_to_terminal | unavailable | 0 | — | — | — | — | us |
| amaru-patched-txsubmission-residence.pending_depth | unavailable | 0 | — | — | — | — | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | unavailable | 0 | — | — | — | — | transactions |
| unacked_depth | unavailable | 0 | — | — | — | — | transactions |
| blocking_residence | unavailable | 0 | — | — | — | — | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
