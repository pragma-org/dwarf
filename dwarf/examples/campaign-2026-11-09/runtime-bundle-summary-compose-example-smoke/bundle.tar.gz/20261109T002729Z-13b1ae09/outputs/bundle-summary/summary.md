# Bundle Summary

- Bundles summarized: 9
- Attestation verified: 1/9
- Attestation coverage pct: 11.11
- Time window start: 2026-04-27T07:40:53.859Z
- Time window end: 2026-04-27T12:01:47.900Z

## By Scenario Family

| family | count |
| --- | ---: |
| runtime-bundle-attestation | 1 |
| runtime-bundle-timeline | 1 |
| runtime-corpus-synthesize | 1 |
| runtime-coverage-report | 2 |
| runtime-forensic-snapshot | 1 |
| runtime-static-analysis | 3 |

## Per Bundle

| run_id | scenario_id | exit | attestation | tags | coverage | throughput | crashes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20260427T074053Z-ba7c46cc | runtime-corpus-synthesize-handshake-smoke | pass | unsigned | - | n/a | n/a | n/a |
| 20260427T085937Z-8e388072 | runtime-coverage-report-example-smoke | pass | unsigned | - | 54.7 | 326246.0 | 0 |
| 20260427T091106Z-3bce7cb4 | runtime-bundle-attestation-example-smoke | pass | verified | - | n/a | n/a | n/a |
| 20260427T095705Z-e51bf913 | runtime-static-analysis-clippy-example-smoke | pass | unsigned | - | n/a | n/a | n/a |
| 20260427T101446Z-289d4fbb | runtime-static-analysis-audit-example-smoke | pass | unsigned | - | n/a | n/a | n/a |
| 20260427T101446Z-977cfbf5 | runtime-static-analysis-deny-example-smoke | pass | unsigned | - | n/a | n/a | n/a |
| 20260427T105341Z-0b24e9a8 | runtime-coverage-report-file-level-aflpp-example-smoke | pass | unsigned | - | n/a | n/a | n/a |
| 20260427T110547Z-419db366 | runtime-bundle-timeline-example-smoke | pass | unsigned | - | n/a | n/a | n/a |
| 20260427T120147Z-8f9884ec | runtime-forensic-snapshot-example-smoke | pass | unsigned | - | n/a | n/a | n/a |

## Top Signatures

| signature_id | scenario_id | exit | sightings |
| --- | --- | --- | ---: |
| 27a8bc69c8c9 | runtime-corpus-synthesize-handshake-smoke | pass | 1 |
| 3ee4faf54f16 | runtime-bundle-attestation-example-smoke | pass | 1 |
| 47de3090c08f | runtime-bundle-timeline-example-smoke | pass | 1 |
| 53304e41db1e | runtime-forensic-snapshot-example-smoke | pass | 1 |
| a1142d1c2c66 | runtime-static-analysis-deny-example-smoke | pass | 1 |
