# DWARF measurement report

Scenario: client-example-txsubmission-window-amaru-portable-20260918
Duration: 54.74398247 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 22 | 1661.0 | 1191.5 | 3324.0 | 5045.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 22 | 1437.8181818181818 | 939.5 | 3247.0 | 4788.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 22 | 6408.863636363636 | 6347.5 | 10371.0 | 11633.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | unavailable | 0 | — | — | — | — | us |
  - transfer_validation: no completed stock telemetry span was exported for transaction-validation
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 22 | 6.045454545454546 | 6.0 | 7.0 | 9.0 | us |
| block_application | available | 22 | 2189.1582272727273 | 519.0795 | 7054.532 | 7330.751 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | available | 2 | 614.5 | 614.5 | 745.0 | 745.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 27 | 0.3374211843261907 | 0.47795972990153274 | 0.9599909105444351 | 0.9606061780239045 | % |
| cpu_time_seconds | available | 28 | — | — | — | — | s |
| rss_bytes | available | 28 | 66760118.85714286 | 66764800.0 | 66805760.0 | 66809856.0 | bytes |
| network_rx_bytes | available | 28 | — | — | — | — | bytes |
| network_tx_bytes | available | 28 | — | — | — | — | bytes |
| disk_read_bytes | available | 28 | — | — | — | — | bytes |
| disk_write_bytes | available | 28 | — | — | — | — | bytes |
| fd_count | available | 28 | 29.0 | 29.0 | 29.0 | 29.0 | fds |
| threads | available | 28 | 28.0 | 28.0 | 28.0 | 28.0 | threads |
| container_memory_bytes | available | 28 | 67135826.96428572 | 67145564.0 | 67192750.0 | 67203235.0 | bytes |
| container_tasks | available | 28 | 28.0 | 28.0 | 28.0 | 28.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_decode | available | 178 | 1.5679101123595507 | 1.172 | 5.04 | 6.252 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 178 | 2.0210449438202245 | 1.3625 | 6.492 | 7.494 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | available | 1 | 2.585 | 2.585 | 2.585 | 2.585 | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | available | 1 | 2.946 | 2.946 | 2.946 | 2.946 | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | available | 1 | 0.741 | 0.741 | 0.741 | 0.741 | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| handler | available | 110 | 31.01150909090909 | 22.448 | 68.512 | 177.099 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 22 | 2.4256363636363636 | 2.4850000000000003 | 3.377 | 3.456 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 110 | 0.8 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 110 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | unavailable | 0 | — | — | — | — | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | unavailable | 0 | — | — | — | — | us |
| body_to_terminal | unavailable | 0 | — | — | — | — | us |
| amaru-patched-txsubmission-residence.pending_depth | unavailable | 0 | — | — | — | — | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | unavailable | 0 | — | — | — | — | transactions |
| unacked_depth | unavailable | 0 | — | — | — | — | transactions |
| blocking_residence | unavailable | 0 | — | — | — | — | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
