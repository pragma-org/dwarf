# DWARF measurement report

Scenario: phase1-runtime-live-amaru-parity-baseline
Duration: 0.292347427 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | unavailable | 0 | — | — | — | — | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | unavailable | 0 | — | — | — | — | transactions |
| mempool_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_sync_duration | unavailable | 0 | — | — | — | — | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | unavailable | 0 | — | — | — | — | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | unavailable | 0 | — | — | — | — | % |
| cpu_time_seconds | unavailable | 0 | — | — | — | — | s |
  - cpu_time_seconds: at least two monotonic counter samples are required
| rss_bytes | unavailable | 0 | — | — | — | — | bytes |
  - rss_bytes: no samples from this source
| network_rx_bytes | unavailable | 0 | — | — | — | — | bytes |
  - network_rx_bytes: at least two monotonic counter samples are required
| network_tx_bytes | unavailable | 0 | — | — | — | — | bytes |
  - network_tx_bytes: at least two monotonic counter samples are required
| disk_read_bytes | unavailable | 0 | — | — | — | — | bytes |
  - disk_read_bytes: at least two monotonic counter samples are required
| disk_write_bytes | unavailable | 0 | — | — | — | — | bytes |
  - disk_write_bytes: at least two monotonic counter samples are required
| fd_count | unavailable | 0 | — | — | — | — | fds |
  - fd_count: no samples from this source
| threads | unavailable | 0 | — | — | — | — | threads |
  - threads: no samples from this source
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
