# Credential Ceremony

- Keys generated: 1
- KES period window: 12
- VRF pubkey hash: `00adc9b0868804cf14e348d691f04d4540ea68abc8df46b92f16d50a0c901094`
- Stake address hash: `192e206aa5bd4bf5c267b3f6c3f42ec27cfe090e148014b14e9416f37d558e60`
- Deterministic seed used: `0xC0EDC0DE`
