# DWARF measurement report

Scenario: cardano-n2n-handshake-version-table-forward-compat-1112
Duration: 3.612559517 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | unavailable | 0 | — | — | — | — | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | unavailable | 0 | — | — | — | — | transactions |
| mempool_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_sync_duration | unavailable | 0 | — | — | — | — | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | unavailable | 0 | — | — | — | — | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 2 | 2.6596480655012384 | 2.6596480655012384 | 3.323166172648198 | 3.323166172648198 | % |
| cpu_time_seconds | available | 3 | — | — | — | — | s |
| rss_bytes | available | 3 | 155987968.0 | 156307456.0 | 156381184.0 | 156381184.0 | bytes |
| network_rx_bytes | available | 3 | — | — | — | — | bytes |
| network_tx_bytes | available | 3 | — | — | — | — | bytes |
| disk_read_bytes | available | 3 | — | — | — | — | bytes |
| disk_write_bytes | available | 3 | — | — | — | — | bytes |
| fd_count | available | 3 | 25.0 | 25.0 | 25.0 | 25.0 | fds |
| threads | available | 3 | 12.0 | 12.0 | 12.0 | 12.0 | threads |
| container_memory_bytes | available | 3 | 143550054.0 | 143759769.0 | 144284057.0 | 144284057.0 | bytes |
| container_tasks | available | 3 | 14.0 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 121 | — | — | — | — | operations |
| attempt_latency | available | 60 | 299.95 | 193.5 | 269.0 | 4531.0 | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_receive_decode | available | 72 | 450019.6882638889 | 24.381999999999998 | 3098455.193 | 10001984.276 | us |
| protocol_receive_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_application | available | 1 | 58.793 | 58.793 | 58.793 | 58.793 | us |
| block_application_by_outcome | unavailable | 0 | — | — | — | — | — |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
| epoch_transition_by_outcome | unavailable | 0 | — | — | — | — | — |
| plutus_vm | unavailable | 0 | — | — | — | — | us |
| plutus_vm_by_outcome | unavailable | 0 | — | — | — | — | — |
