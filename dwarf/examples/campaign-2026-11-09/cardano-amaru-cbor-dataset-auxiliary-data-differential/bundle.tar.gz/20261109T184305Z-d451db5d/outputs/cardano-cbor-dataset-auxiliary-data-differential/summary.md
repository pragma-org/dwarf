# Cardano CBOR Dataset Differential

- Source revision verified: `True`
- Dataset digest: `75ae655fda1c267ab149debfd080a2724873f8e3a08464094e0775d747969ecd`
- Era/rule: `conway/auxiliary_data`
- Category counts: `{"valid": 25, "zap-1": 25, "zap-2": 25, "zap-3": 25}`
- Inputs processed: 100
- Upstream typed verifier passed: `False`
- Upstream verifier failures parsed: `True`
- Reference/candidate mismatches: 0
- Crashes or timeouts: 0
- Clean: `True`

> Scope: typed library decoder evidence only; this is not live-node or protocol-path evidence.
