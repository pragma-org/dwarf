# DWARF measurement report

Scenario: runtime-substrate-txsubmission-unexpected-body-mixed-amaru
Duration: 13.31800213 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | unavailable | 0 | — | — | — | — | events |
  - chain_events: the node traced no ChainSync, ChainDB.AddBlockEvent, Forge.Loop record in this window (namespace not enabled, or silent); a zero would not be a reading
| adopted_blocks | unavailable | 0 | — | — | — | — | blocks |
  - adopted_blocks: the node traced no ChainDB.AddBlockEvent, Forge.Loop record in this window (namespace not enabled, or silent); a zero would not be a reading
| rollbacks | unavailable | 0 | — | — | — | — | events |
  - rollbacks: the node traced no ChainSync.Client, ChainDB.AddBlockEvent record in this window (namespace not enabled, or silent); a zero would not be a reading
| blockfetch_duration | unavailable | 0 | — | — | — | — | us |
  - blockfetch_duration: the node traced no BlockFetch.Client record in this window (namespace not enabled, or silent)
| blockfetch_bytes | unavailable | 0 | — | — | — | — | bytes |
  - blockfetch_bytes: the node traced no BlockFetch.Client record in this window (namespace not enabled, or silent); a zero would not be a reading
| served_blocks | unavailable | 0 | — | — | — | — | blocks |
  - served_blocks: the node traced no BlockFetch.Server record in this window (namespace not enabled, or silent); a zero would not be a reading
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | unavailable | 0 | — | — | — | — | transactions |
  - mempool_accepted: the node traced no Mempool record in this window (namespace not enabled, or silent); a zero would not be a reading
| mempool_rejected | unavailable | 0 | — | — | — | — | transactions |
  - mempool_rejected: the node traced no Mempool record in this window (namespace not enabled, or silent); a zero would not be a reading
| mempool_tx_count | unavailable | 0 | — | — | — | — | transactions |
  - mempool_tx_count: the node traced no Mempool record in this window (namespace not enabled, or silent)
| mempool_bytes | unavailable | 0 | — | — | — | — | bytes |
  - mempool_bytes: the node traced no Mempool record in this window (namespace not enabled, or silent)
| mempool_sync_duration | unavailable | 0 | — | — | — | — | us |
  - mempool_sync_duration: the node traced no Mempool record in this window (namespace not enabled, or silent)
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | unavailable | 0 | — | — | — | — | blocks |
  - cardano-stock-ledger-block-epoch.adopted_blocks: the node traced no ChainDB.AddBlockEvent, Forge.Loop record in this window (namespace not enabled, or silent); a zero would not be a reading
| ledger_samples | unavailable | 0 | — | — | — | — | events |
  - ledger_samples: the node traced no LedgerMetrics record in this window (namespace not enabled, or silent); a zero would not be a reading
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | unavailable | 0 | — | — | — | — | transactions |
  - transaction_outcomes: the node traced no Mempool record in this window (namespace not enabled, or silent); a zero would not be a reading
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | unavailable | 0 | — | — | — | — | us |
  - keepalive_rtt: the node traced no KeepAlive record in this window (namespace not enabled, or silent)
| protocol_events | unavailable | 0 | — | — | — | — | events |
  - protocol_events: the node traced no ChainSync.ServerHeader, BlockFetch, TxSubmission, KeepAlive record in this window (namespace not enabled, or silent); a zero would not be a reading
| cpu_percent | available | 7 | 0.6199681903348646 | 0.47787706066226077 | 0.996508151078236 | 0.996508151078236 | % |
| cpu_time_seconds | available | 8 | — | — | — | — | s |
| rss_bytes | available | 8 | 148090368.0 | 148074496.0 | 148336640.0 | 148336640.0 | bytes |
| network_rx_bytes | available | 8 | — | — | — | — | bytes |
| network_tx_bytes | available | 8 | — | — | — | — | bytes |
| disk_read_bytes | available | 8 | — | — | — | — | bytes |
| disk_write_bytes | available | 8 | — | — | — | — | bytes |
| fd_count | available | 8 | 25.25 | 26.0 | 26.0 | 26.0 | fds |
| threads | available | 8 | 11.0 | 11.0 | 11.0 | 11.0 | threads |
| container_memory_bytes | available | 8 | 85510061.625 | 84908441.5 | 89401589.0 | 89401589.0 | bytes |
| container_tasks | available | 8 | 13.75 | 13.0 | 19.0 | 19.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| header_validation | unavailable | 0 | — | — | — | — | count |
  - header_validation: no header-validation verdict observed in telemetry
