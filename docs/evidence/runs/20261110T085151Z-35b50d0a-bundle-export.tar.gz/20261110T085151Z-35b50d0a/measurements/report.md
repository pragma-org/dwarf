# DWARF measurement report

Scenario: client-example-cbor-decoding-amaru-portable-20260918
Duration: 250.346487851 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 100 | 36293.7 | 1138.0 | 3116.0 | 999351.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 100 | 1470.25 | 1005.5 | 3243.0 | 6123.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 100 | 510014.78 | 3132.5 | 12227.0 | 24501910.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 3 | 2211.6666666666665 | 2012.0 | 3492.0 | 3492.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | unavailable | 0 | — | — | — | — | us |
  - transfer_validation: no completed stock telemetry span was exported for transaction-validation
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 100 | 6.72 | 5.0 | 8.0 | 12.0 | us |
| block_application | available | 97 | 140.31991752577318 | 140.629 | 182.298 | 579.539 | us |
| epoch_transition | available | 2 | 9001.0 | 9001.0 | 9275.0 | 9275.0 | us |
| keepalive_round_trip | available | 8 | 849.375 | 848.5 | 1142.0 | 1142.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 121 | 0.4956324533411921 | 0.47965332353020795 | 0.9612252158602803 | 1.9182334527316707 | % |
| cpu_time_seconds | available | 122 | — | — | — | — | s |
| rss_bytes | available | 122 | 102201646.16393442 | 102242304.0 | 102797312.0 | 102846464.0 | bytes |
| network_rx_bytes | available | 122 | — | — | — | — | bytes |
| network_tx_bytes | available | 122 | — | — | — | — | bytes |
| disk_read_bytes | available | 122 | — | — | — | — | bytes |
| disk_write_bytes | available | 122 | — | — | — | — | bytes |
| fd_count | available | 122 | 28.0327868852459 | 28.0 | 29.0 | 29.0 | fds |
| threads | available | 122 | 28.0 | 28.0 | 28.0 | 28.0 | threads |
| container_memory_bytes | available | 122 | 110880895.12295082 | 110939340.0 | 111463628.0 | 111673344.0 | bytes |
| container_tasks | available | 122 | 28.0 | 28.0 | 28.0 | 28.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_decode | available | 985 | 1.5740598984771574 | 1.292 | 4.709 | 5.741 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 985 | 1.9272335025380711 | 1.503 | 5.801 | 7.144 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | available | 200 | 2.06094 | 1.7734999999999999 | 4.128 | 6.863 | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | available | 200 | 2.285835 | 2.1045 | 3.717 | 5.831 | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | available | 100 | 0.7984399999999999 | 0.721 | 1.473 | 2.475 | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| handler | available | 492 | 27.81738617886179 | 21.982 | 61.278 | 114.439 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 100 | 2.39751 | 2.4095 | 3.426 | 3.727 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 492 | 0.8008130081300813 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 492 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | unavailable | 0 | — | — | — | — | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | unavailable | 0 | — | — | — | — | us |
| body_to_terminal | unavailable | 0 | — | — | — | — | us |
| amaru-patched-txsubmission-residence.pending_depth | unavailable | 0 | — | — | — | — | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | unavailable | 0 | — | — | — | — | transactions |
| unacked_depth | unavailable | 0 | — | — | — | — | transactions |
| blocking_residence | unavailable | 0 | — | — | — | — | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
