# CBOR conformance result

The adapter used the exact production codec boundary for the selected source revision.

Child explanation: The test gave the node 100 messages. It checked whether the node accepted or rejected each message as expected.

| Outcome | Samples | p50 | p95 |
| --- | ---: | ---: | ---: |
| accepted | 25 | 54.966 us | 111.518 us |
| rejected | 75 | 78.030 us | 128.657 us |

Expected outcomes: PASS
Stable second encoding: PASS

Raw nanoseconds are retained in `inputs.ndjson`. Fractional microseconds are derived without removing the sub-microsecond part.
