# DWARF measurement report

Scenario: amaru-measurement-workload-stock-portable
Duration: 1201.123591575 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 500 | 37553.638 | 40.0 | 3910.0 | 1002126.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 500 | 1034.75 | 751.0 | 2469.0 | 4381.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 500 | 4331.094 | 2767.5 | 11929.0 | 13153.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 14 | 2408.9285714285716 | 2006.0 | 4192.0 | 4192.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 80 | 0.5 | 0.5 | 1.0 | 1.0 | tx |
| mempool_size_bytes | available | 80 | 166.125 | 142.5 | 381.0 | 381.0 | bytes |
| mempool_terminal_latency | available | 80 | 1370026.0875 | 110063.5 | 4892138.0 | 9918704.0 | us |
| transfer_validation | available | 42 | 241.38095238095238 | 223.5 | 382.0 | 437.0 | us |
| virtual_machine_acquire_arena | available | 41 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 41 | 3.975609756097561 | 4.0 | 6.0 | 10.0 | us |
| virtual_machine_build_program | available | 41 | 33.21951219512195 | 30.0 | 47.0 | 57.0 | us |
| virtual_machine_evaluate | available | 41 | 24.195121951219512 | 22.0 | 36.0 | 44.0 | us |
| block_prepare | available | 508 | 5.568897637795276 | 5.0 | 11.0 | 20.0 | us |
| block_application | available | 486 | 102.26954732510288 | 96.0 | 166.0 | 265.0 | us |
| epoch_transition | available | 6 | 10173.5 | 10066.5 | 14820.0 | 14820.0 | us |
| keepalive_round_trip | available | 29 | 716.3103448275862 | 749.0 | 1037.0 | 1037.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 465 | 0.3763115071600418 | 0.3880489701283613 | 0.7772362986111074 | 1.553807329720138 | % |
| cpu_time_seconds | available | 467 | — | — | — | — | s |
| rss_bytes | available | 467 | 82246636.26552463 | 83324928.0 | 84668416.0 | 84987904.0 | bytes |
| network_rx_bytes | available | 467 | — | — | — | — | bytes |
| network_tx_bytes | available | 467 | — | — | — | — | bytes |
| disk_read_bytes | available | 467 | — | — | — | — | bytes |
| disk_write_bytes | available | 467 | — | — | — | — | bytes |
| fd_count | available | 467 | 28.62740899357602 | 29.0 | 31.0 | 31.0 | fds |
| threads | available | 467 | 28.008565310492504 | 28.0 | 28.0 | 29.0 | threads |
| container_memory_bytes | available | 467 | 60731814.98072805 | 59433287.0 | 69006786.0 | 69195530.0 | bytes |
| container_tasks | available | 467 | 28.01713062098501 | 28.0 | 28.0 | 29.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 243 | — | — | — | — | operations |
| attempt_latency | available | 121 | 719355.4478264464 | 101244.0 | 4262005.857 | 8787087.585 | us |
| submit_to_protocol_response | available | 21 | 645868.3125714285 | 648142.012 | 675287.982 | 691714.258 | us |
| submit_to_mempool_visibility | available | 20 | 162387.22625 | 163774.123 | 171829.826 | 171904.164 | us |
| submit_to_block_inclusion | available | 20 | 3817824.2424500003 | 3026635.8015 | 8787087.585 | 10023382.646 | us |
| submit_to_chain_adoption | available | 20 | 3817824.2424500003 | 3026635.8015 | 8787087.585 | 10023382.646 | us |
| header_validation | available | 0 | — | — | — | — | count |
