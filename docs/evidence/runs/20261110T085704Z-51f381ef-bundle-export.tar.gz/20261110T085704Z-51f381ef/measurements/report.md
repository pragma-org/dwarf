# DWARF measurement report

Scenario: client-example-invalid-mini-protocol-amaru-portable-20260918
Duration: 320.173694338 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 112 | 32359.76785714286 | 1056.5 | 2326.0 | 3303.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 112 | 1272.3660714285713 | 967.5 | 2650.0 | 3415.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 112 | 357476.66964285716 | 3026.0 | 12154.0 | 66142.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 3 | 2370.0 | 1813.0 | 4262.0 | 4262.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | unavailable | 0 | — | — | — | — | us |
  - transfer_validation: no completed stock telemetry span was exported for transaction-validation
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 112 | 5.946428571428571 | 5.0 | 8.0 | 30.0 | us |
| block_application | available | 109 | 142.05018348623852 | 133.085 | 222.085 | 379.706 | us |
| epoch_transition | available | 2 | 9469.5 | 9469.5 | 11191.0 | 11191.0 | us |
| keepalive_round_trip | available | 10 | 805.2 | 785.5 | 1048.0 | 1048.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 154 | 0.45731580606483546 | 0.4794681504635988 | 0.9602441516103608 | 2.3974339652356904 | % |
| cpu_time_seconds | available | 155 | — | — | — | — | s |
| rss_bytes | available | 155 | 103757705.08387096 | 103755776.0 | 104521728.0 | 104574976.0 | bytes |
| network_rx_bytes | available | 155 | — | — | — | — | bytes |
| network_tx_bytes | available | 155 | — | — | — | — | bytes |
| disk_read_bytes | available | 155 | — | — | — | — | bytes |
| disk_write_bytes | available | 155 | — | — | — | — | bytes |
| fd_count | available | 155 | 29.548387096774192 | 30.0 | 30.0 | 30.0 | fds |
| threads | available | 155 | 28.0 | 28.0 | 28.0 | 28.0 | threads |
| container_memory_bytes | available | 155 | 112441848.34193549 | 112512204.0 | 113141350.0 | 113351065.0 | bytes |
| container_tasks | available | 155 | 28.0 | 28.0 | 28.0 | 28.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_decode | available | 1101 | 1.6416893732970028 | 1.213 | 5.089 | 6.021 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 1101 | 1.9879246139872842 | 1.462 | 6.262 | 7.254 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | available | 200 | 2.07902 | 1.733 | 4.138 | 6.181 | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | available | 200 | 2.37533 | 2.1445 | 4.117 | 6.332 | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | available | 100 | 0.8464700000000001 | 0.7164999999999999 | 1.663 | 1.914 | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| handler | available | 556 | 29.139920863309353 | 22.0875 | 67.499 | 110.732 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 112 | 2.6055357142857143 | 2.3595 | 4.349 | 8.596 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 556 | 0.8003597122302158 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 556 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | unavailable | 0 | — | — | — | — | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | unavailable | 0 | — | — | — | — | us |
| body_to_terminal | unavailable | 0 | — | — | — | — | us |
| amaru-patched-txsubmission-residence.pending_depth | unavailable | 0 | — | — | — | — | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | unavailable | 0 | — | — | — | — | transactions |
| unacked_depth | unavailable | 0 | — | — | — | — | transactions |
| blocking_residence | unavailable | 0 | — | — | — | — | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
