# DWARF measurement report

Scenario: conway-gov-scriptcontext-proposals-votes-fidelity-amaru-cardano-node
Duration: 137.355330417 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 4 | 1906.5 | 1653.0 | 2786.0 | 2786.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 4 | 1072.25 | 415.5 | 3086.0 | 3086.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 528 | 25207.602272727272 | 29293.5 | 39074.0 | 40256.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 2 | 1.5 | 1.5 | 2.0 | 2.0 | tx |
| mempool_size_bytes | available | 2 | 1602.5 | 1602.5 | 2018.0 | 2018.0 | bytes |
| mempool_terminal_latency | available | 2 | 895.5 | 895.5 | 1008.0 | 1008.0 | us |
| transfer_validation | available | 4 | 179.25 | 154.5 | 289.0 | 289.0 | us |
| virtual_machine_acquire_arena | available | 4 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 4 | 30.5 | 32.0 | 35.0 | 35.0 | us |
| virtual_machine_build_program | available | 4 | 44.25 | 46.5 | 50.0 | 50.0 | us |
| virtual_machine_evaluate | available | 4 | 95.0 | 101.0 | 102.0 | 102.0 | us |
| block_prepare | available | 2164 | 5.279574861367838 | 5.0 | 8.0 | 19.0 | us |
| block_application | available | 4 | 96.0 | 89.0 | 124.0 | 124.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | available | 4 | 453.0 | 406.0 | 643.0 | 643.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 35 | 0.2181325361591718 | 0.0 | 0.48094535221806217 | 1.4329455309467973 | % |
| cpu_time_seconds | available | 36 | — | — | — | — | s |
| rss_bytes | available | 36 | 89779086.22222222 | 90322944.0 | 90738688.0 | 90836992.0 | bytes |
| network_rx_bytes | available | 36 | — | — | — | — | bytes |
| network_tx_bytes | available | 36 | — | — | — | — | bytes |
| disk_read_bytes | available | 36 | — | — | — | — | bytes |
| disk_write_bytes | available | 36 | — | — | — | — | bytes |
| fd_count | available | 36 | 29.0 | 29.0 | 29.0 | 29.0 | fds |
| threads | available | 36 | 30.305555555555557 | 30.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 36 | 70216434.97222222 | 71177338.0 | 71250739.0 | 71313653.0 | bytes |
| container_tasks | available | 36 | 32.30555555555556 | 32.0 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
