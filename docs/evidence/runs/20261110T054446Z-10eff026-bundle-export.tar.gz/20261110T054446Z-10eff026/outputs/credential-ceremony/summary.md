# Credential Ceremony

- Keys generated: 1
- KES period window: 1
- VRF pubkey hash: `5c6623e33e7fbe68864596f341bd480626276dbcf5d2aa4dca38c97c83a2774c`
- Stake address hash: `d22043f09cdc5b61459af38fa31ce35aca0c305f6e57e13b8d56c5c8aaf22378`
- Deterministic seed used: `runtime-starvation-real-adapter`
