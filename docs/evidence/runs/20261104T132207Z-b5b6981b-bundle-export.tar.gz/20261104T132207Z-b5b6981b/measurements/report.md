# DWARF measurement report

Scenario: cardano-measurement-workload-stock-portable
Duration: 305.85547511 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 71 | 4502.142788732394 | 4377.788 | 6003.129 | 6849.929 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | available | 81 | 0.49382716049382713 | 0.0 | 1.0 | 1.0 | transactions |
| mempool_bytes | available | 81 | 164.69135802469137 | 0.0 | 385.0 | 385.0 | bytes |
| mempool_sync_duration | unavailable | 0 | — | — | — | — | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 42 | 764.047619047619 | 794.5 | 1081.0 | 1465.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 117 | 2.101115800954169 | 1.931355699446017 | 2.70477919730936 | 3.0882471538975698 | % |
| cpu_time_seconds | available | 119 | — | — | — | — | s |
| rss_bytes | available | 119 | 174482475.02521008 | 176336896.0 | 177242112.0 | 177377280.0 | bytes |
| network_rx_bytes | available | 119 | — | — | — | — | bytes |
| network_tx_bytes | available | 119 | — | — | — | — | bytes |
| disk_read_bytes | available | 119 | — | — | — | — | bytes |
| disk_write_bytes | available | 119 | — | — | — | — | bytes |
| fd_count | available | 119 | 27.18487394957983 | 26.0 | 33.0 | 34.0 | fds |
| threads | available | 119 | 11.974789915966387 | 12.0 | 12.0 | 12.0 | threads |
| container_memory_bytes | available | 119 | 72382672.10924369 | 74333552.0 | 75193384.0 | 75319214.0 | bytes |
| container_tasks | available | 119 | 13.974789915966387 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 123 | — | — | — | — | operations |
| attempt_latency | available | 122 | 425222.73036065575 | 178.5 | 2714414.55 | 5317890.196 | us |
| submit_to_protocol_response | available | 11 | 346178.05863636365 | 345369.059 | 359990.958 | 359990.958 | us |
| submit_to_mempool_visibility | available | 21 | 168281.0247142857 | 165765.575 | 193473.383 | 195100.255 | us |
| submit_to_block_inclusion | available | 20 | 2558482.38715 | 1913136.376 | 5317890.196 | 7811893.925 | us |
| submit_to_chain_adoption | available | 10 | 2395464.4436999997 | 1872975.129 | 5317890.196 | 5317890.196 | us |
| protocol_receive_decode | available | 2250 | 1081653.8167453334 | 593.451 | 5501327.424 | 10002077.742 | us |
| protocol_receive_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_application | available | 582 | 46.30868384879725 | 17.1175 | 245.871 | 369.387 | us |
| block_application_by_outcome | unavailable | 0 | — | — | — | — | — |
| epoch_transition | available | 24 | 96.04424999999999 | 72.5185 | 142.153 | 310.704 | us |
| epoch_transition_by_outcome | unavailable | 0 | — | — | — | — | — |
| plutus_vm | available | 46 | 51.64147826086956 | 54.5245 | 70.465 | 75.424 | us |
| plutus_vm_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_validation | available | 0 | — | — | — | — | count |
| cardano-patched-header-validation.header_validation | available | 471 | 352.4638407643312 | 312.909 | 568.198 | 792.056 | us |
| header_validation_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_prerequisite_unavailable | unavailable | 0 | — | — | — | — | us |
| queue_residence_lower_bound | available | 97 | 0.0 | 0.0 | 0.0 | 0.0 | microseconds |
| queue_residence_upper_bound | available | 97 | 66.9639175257732 | 54.905 | 141.772 | 699.108 | microseconds |
| handler_service | available | 98 | 20.898693877551022 | 19.7375 | 29.065 | 47.591 | microseconds |
| pending_range_depth | available | 194 | 0.5 | 0.5 | 1.0 | 1.0 | ranges |
| request_to_body_lower_bound | available | 20 | 870.1311499999999 | 693.7035 | 1772.273 | 2401.337 | microseconds |
| request_to_body_upper_bound | available | 20 | 907.8958500000001 | 731.2195 | 1801.94 | 2432.607 | microseconds |
| body_to_terminal_lower_bound | available | 20 | 46.7313 | 41.173500000000004 | 66.337 | 77.849 | microseconds |
| body_to_terminal_upper_bound | available | 20 | 92.7179 | 82.173 | 127.634 | 131.902 | microseconds |
| request_to_terminal_lower_bound | available | 20 | 950.90205 | 769.077 | 1834.472 | 2469.537 | microseconds |
| request_to_terminal_upper_bound | available | 20 | 966.57415 | 781.8115 | 1844.511 | 2480.539 | microseconds |
| pending_body_depth | available | 60 | 0.3333333333333333 | 0.0 | 1.0 | 1.0 | transactions |
| inflight_body_depth | available | 60 | 0.6666666666666666 | 1.0 | 1.0 | 1.0 | transactions |
