# DWARF measurement report

Scenario: amaru-measurement-e2e-stock-portable
Duration: 12.543400488 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 5 | 1070.0 | 992.0 | 1542.0 | 1542.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 5 | 1134.6 | 787.0 | 2114.0 | 2114.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 5 | 2925.0 | 3023.0 | 4338.0 | 4338.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | unavailable | 0 | — | — | — | — | us |
  - transfer_validation: no completed stock telemetry span was exported for transaction-validation
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 5 | 5.0 | 5.0 | 6.0 | 6.0 | us |
| block_application | available | 5 | 111.6 | 106.0 | 156.0 | 156.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | unavailable | 0 | — | — | — | — | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 6 | 1.7516666666666667 | 1.975 | 2.66 | 2.66 | % |
| cpu_time_seconds | unavailable | 0 | — | — | — | — | s |
  - cpu_time_seconds: at least two monotonic counter samples are required
| rss_bytes | unavailable | 0 | — | — | — | — | bytes |
| network_rx_bytes | available | 0 | — | — | — | — | bytes |
| network_tx_bytes | available | 0 | — | — | — | — | bytes |
| disk_read_bytes | available | 0 | — | — | — | — | bytes |
| disk_write_bytes | available | 0 | — | — | — | — | bytes |
| fd_count | unavailable | 0 | — | — | — | — | fds |
| threads | unavailable | 0 | — | — | — | — | threads |
| container_memory_bytes | available | 6 | 60553516.0 | 60633907.0 | 60964208.0 | 60964208.0 | bytes |
| container_tasks | available | 6 | 30.0 | 30.0 | 30.0 | 30.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
| attempt_latency | available | 100 | 100275.88 | 101179.5 | 101989.0 | 102037.0 | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
