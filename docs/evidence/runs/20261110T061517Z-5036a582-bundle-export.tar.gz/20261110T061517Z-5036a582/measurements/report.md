# DWARF measurement report

Scenario: ledger-epoch-boundary-donation-treasury-realization-amaru-cardano-node
Duration: 287.789652335 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 118 | 835.7118644067797 | 765.5 | 1477.0 | 1964.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 118 | 64238.0593220339 | 81802.0 | 83119.0 | 83489.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 134 | 60327.89552238806 | 83464.0 | 85573.0 | 120227.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | available | 3 | 224.66666666666666 | 193.0 | 332.0 | 332.0 | us |
| virtual_machine_acquire_arena | available | 1 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 1 | 11.0 | 11.0 | 11.0 | 11.0 | us |
| virtual_machine_build_program | available | 1 | 29.0 | 29.0 | 29.0 | 29.0 | us |
| virtual_machine_evaluate | available | 1 | 39.0 | 39.0 | 39.0 | 39.0 | us |
| block_prepare | available | 142 | 8.26056338028169 | 7.0 | 18.0 | 37.0 | us |
| block_application | available | 118 | 143.53389830508473 | 140.5 | 238.0 | 276.0 | us |
| epoch_transition | available | 2 | 8184.5 | 8184.5 | 10035.0 | 10035.0 | us |
| keepalive_round_trip | available | 11 | 2648.909090909091 | 2839.0 | 3296.0 | 3296.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 9 | 0.31836971262802627 | 0.47460361911134474 | 0.9527132875019646 | 0.9527132875019646 | % |
| cpu_time_seconds | available | 10 | — | — | — | — | s |
| rss_bytes | available | 10 | 71899545.6 | 72034304.0 | 72093696.0 | 72093696.0 | bytes |
| network_rx_bytes | available | 10 | — | — | — | — | bytes |
| network_tx_bytes | available | 10 | — | — | — | — | bytes |
| disk_read_bytes | available | 10 | — | — | — | — | bytes |
| disk_write_bytes | available | 10 | — | — | — | — | bytes |
| fd_count | available | 10 | 29.0 | 29.0 | 29.0 | 29.0 | fds |
| threads | available | 10 | 30.3 | 30.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 10 | 50226789.9 | 50163875.0 | 50803507.0 | 50803507.0 | bytes |
| container_tasks | available | 10 | 32.3 | 32.0 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
