# Credential Ceremony

- Keys generated: 1
- KES period window: 1
- VRF pubkey hash: `46e2b4a2b193e710d3cb334cfde156643a4ea67c4e8ac8b30a2c2d601fa5d57b`
- Stake address hash: `209fe703567e57f8d8ab579137265c3539abf8baebd4f41d25b33853dcb32dae`
- Deterministic seed used: `blocking-work-real-adapter`
