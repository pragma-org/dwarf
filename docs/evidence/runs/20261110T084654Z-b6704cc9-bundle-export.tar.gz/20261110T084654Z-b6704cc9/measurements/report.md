# DWARF measurement report

Scenario: client-example-block-application-amaru-portable-20260918
Duration: 236.555017479 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 89 | 68495.60674157304 | 1204.0 | 2766.0 | 2985285.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 89 | 1161.5280898876404 | 816.0 | 3200.0 | 5613.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 89 | 835816.3370786516 | 3003.0 | 44447.0 | 28500171.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 2 | 2124.5 | 2124.5 | 2267.0 | 2267.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | unavailable | 0 | — | — | — | — | us |
  - transfer_validation: no completed stock telemetry span was exported for transaction-validation
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 88 | 9.068181818181818 | 5.0 | 11.0 | 122.0 | us |
| block_application | available | 86 | 137.50627906976746 | 133.46 | 164.806 | 451.614 | us |
| epoch_transition | available | 1 | 11204.0 | 11204.0 | 11204.0 | 11204.0 | us |
| keepalive_round_trip | available | 8 | 782.0 | 816.5 | 974.0 | 974.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 114 | 0.3744200147623883 | 0.47884993245011587 | 0.9598445335902668 | 2.8796469538557936 | % |
| cpu_time_seconds | available | 115 | — | — | — | — | s |
| rss_bytes | available | 115 | 101260350.33043478 | 101146624.0 | 101695488.0 | 101715968.0 | bytes |
| network_rx_bytes | available | 115 | — | — | — | — | bytes |
| network_tx_bytes | available | 115 | — | — | — | — | bytes |
| disk_read_bytes | available | 115 | — | — | — | — | bytes |
| disk_write_bytes | available | 115 | — | — | — | — | bytes |
| fd_count | available | 115 | 28.408695652173915 | 27.0 | 30.0 | 30.0 | fds |
| threads | available | 115 | 28.0 | 28.0 | 28.0 | 28.0 | threads |
| container_memory_bytes | available | 115 | 109922677.63478261 | 109890764.0 | 110519910.0 | 110624768.0 | bytes |
| container_tasks | available | 115 | 28.0 | 28.0 | 28.0 | 28.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_decode | available | 707 | 1.401960396039604 | 0.952 | 5.05 | 6.122 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 707 | 1.8087100424328149 | 1.132 | 6.413 | 7.394 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | unavailable | 0 | — | — | — | — | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | unavailable | 0 | — | — | — | — | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | unavailable | 0 | — | — | — | — | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| handler | available | 432 | 24.91014583333333 | 21.987000000000002 | 56.849 | 77.869 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 88 | 2.2698068181818183 | 2.249 | 3.317 | 3.517 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 432 | 0.8009259259259259 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 432 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | unavailable | 0 | — | — | — | — | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | unavailable | 0 | — | — | — | — | us |
| body_to_terminal | unavailable | 0 | — | — | — | — | us |
| amaru-patched-txsubmission-residence.pending_depth | unavailable | 0 | — | — | — | — | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | unavailable | 0 | — | — | — | — | transactions |
| unacked_depth | unavailable | 0 | — | — | — | — | transactions |
| blocking_residence | unavailable | 0 | — | — | — | — | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
