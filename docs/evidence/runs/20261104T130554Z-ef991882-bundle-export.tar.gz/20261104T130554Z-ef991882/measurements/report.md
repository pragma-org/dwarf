# DWARF measurement report

Scenario: cardano-measurement-workload-stock-portable
Duration: 330.024715621 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 82 | 4745.360536585366 | 4343.169 | 6629.0960000000005 | 14878.484 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | available | 81 | 0.49382716049382713 | 0.0 | 1.0 | 1.0 | transactions |
| mempool_bytes | available | 81 | 164.69135802469137 | 0.0 | 385.0 | 385.0 | bytes |
| mempool_sync_duration | unavailable | 0 | — | — | — | — | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 52 | 616.9230769230769 | 598.5 | 952.0 | 1269.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 127 | 2.05268047852438 | 1.9289781097981649 | 3.07744528745611 | 3.470404133894791 | % |
| cpu_time_seconds | available | 129 | — | — | — | — | s |
| rss_bytes | available | 129 | 167165539.2248062 | 169504768.0 | 169906176.0 | 169910272.0 | bytes |
| network_rx_bytes | available | 129 | — | — | — | — | bytes |
| network_tx_bytes | available | 129 | — | — | — | — | bytes |
| disk_read_bytes | available | 129 | — | — | — | — | bytes |
| disk_write_bytes | available | 129 | — | — | — | — | bytes |
| fd_count | available | 129 | 25.503875968992247 | 24.0 | 31.0 | 32.0 | fds |
| threads | available | 129 | 11.852713178294573 | 12.0 | 12.0 | 12.0 | threads |
| container_memory_bytes | available | 129 | 67964875.40310077 | 70296535.0 | 70946652.0 | 71355596.0 | bytes |
| container_tasks | available | 129 | 13.852713178294573 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 123 | — | — | — | — | operations |
| attempt_latency | available | 122 | 570253.0182131148 | 166.0 | 4373556.303 | 7880333.038 | us |
| submit_to_protocol_response | available | 11 | 334905.4811818182 | 329023.452 | 360910.616 | 360910.616 | us |
| submit_to_mempool_visibility | available | 21 | 166568.61819047618 | 164497.376 | 182158.07 | 194961.162 | us |
| submit_to_block_inclusion | available | 20 | 3443850.9865999995 | 2669954.622 | 7880333.038 | 8819546.243 | us |
| submit_to_chain_adoption | available | 10 | 3814209.6881999997 | 3535492.3540000003 | 8819546.243 | 8819546.243 | us |
| header_validation | available | 0 | — | — | — | — | count |
