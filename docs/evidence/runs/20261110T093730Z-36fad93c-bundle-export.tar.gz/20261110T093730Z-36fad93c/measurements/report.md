# DWARF measurement report

Scenario: plutus-onchain-cek-integer-division-differential-amaru-cardano-node
Duration: 108.387284496 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 5 | 1556.2 | 1551.0 | 1640.0 | 1640.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 5 | 679.8 | 495.0 | 1532.0 | 1532.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 5 | 3026.8 | 2753.0 | 4397.0 | 4397.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 4 | 0.5 | 0.5 | 1.0 | 1.0 | tx |
| mempool_size_bytes | available | 4 | 227.0 | 195.5 | 517.0 | 517.0 | bytes |
| mempool_terminal_latency | available | 6 | 1886942.8333333333 | 924.0 | 9124576.0 | 9124576.0 | us |
| transfer_validation | available | 5 | 304.4 | 212.0 | 758.0 | 758.0 | us |
| virtual_machine_acquire_arena | available | 8 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 8 | 13.75 | 8.5 | 54.0 | 54.0 | us |
| virtual_machine_build_program | available | 8 | 26.5 | 25.0 | 44.0 | 44.0 | us |
| virtual_machine_evaluate | available | 8 | 27.625 | 23.0 | 44.0 | 44.0 | us |
| block_prepare | available | 5 | 6.0 | 5.0 | 9.0 | 9.0 | us |
| block_application | available | 5 | 88.0 | 88.0 | 94.0 | 94.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | available | 4 | 571.5 | 555.0 | 734.0 | 734.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 52 | 0.1849277077080197 | 0.0 | 0.9590862196737046 | 0.9839427988216201 | % |
| cpu_time_seconds | available | 53 | — | — | — | — | s |
| rss_bytes | available | 53 | 88055112.4528302 | 87760896.0 | 89161728.0 | 89165824.0 | bytes |
| network_rx_bytes | available | 53 | — | — | — | — | bytes |
| network_tx_bytes | available | 53 | — | — | — | — | bytes |
| disk_read_bytes | available | 53 | — | — | — | — | bytes |
| disk_write_bytes | available | 53 | — | — | — | — | bytes |
| fd_count | available | 53 | 28.0 | 28.0 | 28.0 | 28.0 | fds |
| threads | available | 53 | 30.358490566037737 | 30.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 53 | 69762552.20754717 | 69289902.0 | 71020052.0 | 71020052.0 | bytes |
| container_tasks | available | 53 | 32.35849056603774 | 32.0 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
