# Plutus V2 evaluator conformance

Cost model: `sha256:675a27a3c1f2f9b32954c67c1f0ad21479713eef5513386638d78e05f5e277cc` (175 ordered parameters).

Raw nanoseconds are retained. Human-facing microseconds preserve the fractional part.

- amaru accepted: n=30, p50=58.402 us, p95=79.703 us
- amaru rejected: n=30, p50=55.596 us, p95=91.655 us
- cardano-node accepted: n=30, p50=10.570 us, p95=13.736 us
- cardano-node rejected: n=30, p50=40.958 us, p95=52.921 us
