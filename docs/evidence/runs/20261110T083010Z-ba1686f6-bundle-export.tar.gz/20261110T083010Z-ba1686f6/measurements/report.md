# DWARF measurement report

Scenario: client-example-plutus-vm-amaru-portable-20260918
Duration: 734.152581644 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 301 | 57742.52159468438 | 1081.0 | 4013.0 | 1503417.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 301 | 1597.810631229236 | 1081.0 | 4581.0 | 6489.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 301 | 497259.8970099668 | 3529.0 | 17730.0 | 17999410.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 12 | 5978.416666666667 | 2291.0 | 43006.0 | 43006.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | available | 125 | 244.152 | 221.0 | 382.0 | 460.0 | us |
| virtual_machine_acquire_arena | available | 62 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 62 | 5.790322580645161 | 4.0 | 6.0 | 103.0 | us |
| virtual_machine_build_program | available | 62 | 42.435483870967744 | 44.5 | 62.0 | 77.0 | us |
| virtual_machine_evaluate | available | 62 | 26.306451612903224 | 26.0 | 35.0 | 95.0 | us |
| block_prepare | available | 301 | 6.930232558139535 | 6.0 | 10.0 | 29.0 | us |
| block_application | available | 289 | 155.62437370242216 | 150.358 | 203.399 | 563.349 | us |
| epoch_transition | available | 3 | 10047.0 | 9008.0 | 13227.0 | 13227.0 | us |
| keepalive_round_trip | available | 25 | 449.2 | 423.0 | 794.0 | 812.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 352 | 0.3603273298214181 | 0.47401304746124306 | 0.9599065552840319 | 3.335271105138118 | % |
| cpu_time_seconds | available | 353 | — | — | — | — | s |
| rss_bytes | available | 353 | 80394396.64589235 | 80412672.0 | 81268736.0 | 81301504.0 | bytes |
| network_rx_bytes | available | 353 | — | — | — | — | bytes |
| network_tx_bytes | available | 353 | — | — | — | — | bytes |
| disk_read_bytes | available | 353 | — | — | — | — | bytes |
| disk_write_bytes | available | 353 | — | — | — | — | bytes |
| fd_count | available | 353 | 28.192634560906516 | 28.0 | 29.0 | 29.0 | fds |
| threads | available | 353 | 28.0 | 28.0 | 28.0 | 28.0 | threads |
| container_memory_bytes | available | 353 | 60548104.68271954 | 60544778.0 | 61415096.0 | 61457039.0 | bytes |
| container_tasks | available | 353 | 28.0 | 28.0 | 28.0 | 28.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 1 | — | — | — | — | operations |
| attempt_latency | available | 63 | 3464742.5398095236 | 3361475.815 | 7078301.594 | 8400922.774 | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | available | 60 | 3602113.7624500003 | 3365270.7915 | 7078301.594 | 8400922.774 | us |
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_decode | available | 2406 | 1.5086263507896924 | 0.972 | 5.06 | 5.991 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 2406 | 1.8897456359102245 | 1.1625 | 6.332 | 7.455 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | unavailable | 0 | — | — | — | — | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | unavailable | 0 | — | — | — | — | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | unavailable | 0 | — | — | — | — | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| handler | available | 1477 | 33.57252606635071 | 22.102 | 75.374 | 181.367 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 301 | 3.73234219269103 | 2.736 | 5.21 | 13.055 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 1477 | 0.8009478672985783 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 1477 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | unavailable | 0 | — | — | — | — | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | unavailable | 0 | — | — | — | — | us |
| body_to_terminal | unavailable | 0 | — | — | — | — | us |
| amaru-patched-txsubmission-residence.pending_depth | unavailable | 0 | — | — | — | — | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | unavailable | 0 | — | — | — | — | transactions |
| unacked_depth | unavailable | 0 | — | — | — | — | transactions |
| blocking_residence | unavailable | 0 | — | — | — | — | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
