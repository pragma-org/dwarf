# DWARF measurement report

Scenario: plutus-onchain-bls12-381-builtins-differential-amaru-cardano-node
Duration: 128.732380842 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 4 | 2127.0 | 2082.0 | 2818.0 | 2818.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 4 | 630.25 | 559.0 | 935.0 | 935.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 4 | 3581.0 | 3486.5 | 4678.0 | 4678.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 4 | 1.0 | 1.0 | 2.0 | 2.0 | tx |
| mempool_size_bytes | available | 4 | 488.25 | 446.0 | 1061.0 | 1061.0 | bytes |
| mempool_terminal_latency | available | 5 | 11648754.6 | 1045.0 | 58237788.0 | 58237788.0 | us |
| transfer_validation | available | 3 | 241.0 | 201.0 | 378.0 | 378.0 | us |
| virtual_machine_acquire_arena | available | 6 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 6 | 7.666666666666667 | 7.0 | 15.0 | 15.0 | us |
| virtual_machine_build_program | available | 6 | 38.5 | 35.5 | 74.0 | 74.0 | us |
| virtual_machine_evaluate | available | 6 | 435.8333333333333 | 46.5 | 2316.0 | 2316.0 | us |
| block_prepare | available | 4 | 7.5 | 7.0 | 12.0 | 12.0 | us |
| block_application | available | 4 | 97.5 | 93.0 | 125.0 | 125.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | available | 4 | 401.25 | 396.0 | 481.0 | 481.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 62 | 0.17043315209790705 | 0.0 | 0.9539563739727934 | 1.442138397905267 | % |
| cpu_time_seconds | available | 63 | — | — | — | — | s |
| rss_bytes | available | 63 | 88275041.52380952 | 87756800.0 | 89497600.0 | 90050560.0 | bytes |
| network_rx_bytes | available | 63 | — | — | — | — | bytes |
| network_tx_bytes | available | 63 | — | — | — | — | bytes |
| disk_read_bytes | available | 63 | — | — | — | — | bytes |
| disk_write_bytes | available | 63 | — | — | — | — | bytes |
| fd_count | available | 63 | 28.0 | 28.0 | 28.0 | 28.0 | fds |
| threads | available | 63 | 30.333333333333332 | 30.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 63 | 68490653.68253969 | 67475865.0 | 70495764.0 | 70674022.0 | bytes |
| container_tasks | available | 63 | 32.333333333333336 | 32.0 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
