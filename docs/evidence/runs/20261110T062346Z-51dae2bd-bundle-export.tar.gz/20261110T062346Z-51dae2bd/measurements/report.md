# DWARF measurement report

Scenario: ledger-submit-empty-redeemers-container-differential-amaru-cardano-node
Duration: 176.771120364 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 10 | 1996.6 | 1590.0 | 3781.0 | 3781.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 10 | 1041.9 | 920.5 | 1953.0 | 1953.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 10 | 3830.5 | 3255.5 | 5971.0 | 5971.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 4 | 0.5 | 0.5 | 1.0 | 1.0 | tx |
| mempool_size_bytes | available | 4 | 145.0 | 98.5 | 383.0 | 383.0 | bytes |
| mempool_terminal_latency | available | 14 | 2557486.5 | 448.0 | 25997810.0 | 25997810.0 | us |
| transfer_validation | available | 5 | 192.6 | 205.0 | 226.0 | 226.0 | us |
| virtual_machine_acquire_arena | available | 3 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 3 | 9.0 | 3.0 | 21.0 | 21.0 | us |
| virtual_machine_build_program | available | 3 | 47.0 | 25.0 | 92.0 | 92.0 | us |
| virtual_machine_evaluate | available | 3 | 41.333333333333336 | 22.0 | 86.0 | 86.0 | us |
| block_prepare | available | 10 | 6.6 | 6.0 | 13.0 | 13.0 | us |
| block_application | available | 10 | 125.9 | 126.0 | 158.0 | 158.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | available | 6 | 441.6666666666667 | 423.5 | 644.0 | 644.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 85 | 0.1749007804769078 | 0.0 | 0.48069446458765047 | 0.9605223734274458 | % |
| cpu_time_seconds | available | 86 | — | — | — | — | s |
| rss_bytes | available | 86 | 87659781.95348836 | 87547904.0 | 88895488.0 | 88997888.0 | bytes |
| network_rx_bytes | available | 86 | — | — | — | — | bytes |
| network_tx_bytes | available | 86 | — | — | — | — | bytes |
| disk_read_bytes | available | 86 | — | — | — | — | bytes |
| disk_write_bytes | available | 86 | — | — | — | — | bytes |
| fd_count | available | 86 | 28.0 | 28.0 | 28.0 | 28.0 | fds |
| threads | available | 86 | 30.348837209302324 | 30.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 86 | 68259858.56976745 | 67538780.0 | 70443335.0 | 70537707.0 | bytes |
| container_tasks | available | 86 | 32.33720930232558 | 32.0 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
