# DWARF measurement report

Scenario: governance-zero-denominator-admission-differential-amaru-cardano-node
Duration: 326.486437224 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 13 | 1777.4615384615386 | 1691.0 | 2362.0 | 2362.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 13 | 904.5384615384615 | 747.0 | 2485.0 | 2485.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 526 | 27924.91254752852 | 30188.0 | 40308.0 | 40801.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 4 | 1.0 | 1.0 | 2.0 | 2.0 | tx |
| mempool_size_bytes | available | 4 | 474.0 | 554.5 | 787.0 | 787.0 | bytes |
| mempool_terminal_latency | available | 4 | 5252404.25 | 816.0 | 21007608.0 | 21007608.0 | us |
| transfer_validation | available | 4 | 200.0 | 215.5 | 230.0 | 230.0 | us |
| virtual_machine_acquire_arena | available | 10 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 10 | 4.8 | 3.5 | 15.0 | 15.0 | us |
| virtual_machine_build_program | available | 10 | 37.9 | 31.5 | 60.0 | 60.0 | us |
| virtual_machine_evaluate | available | 10 | 21.0 | 14.0 | 44.0 | 44.0 | us |
| block_prepare | available | 527 | 22.246679316888045 | 5.0 | 19.0 | 33.0 | us |
| block_application | available | 13 | 100.84615384615384 | 91.0 | 150.0 | 150.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | available | 7 | 788.7142857142857 | 683.0 | 1650.0 | 1650.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 156 | 1.2690831212127038 | 0.0 | 0.9581729167876918 | 0.9610439458935577 | % |
| cpu_time_seconds | available | 158 | — | — | — | — | s |
| rss_bytes | available | 158 | 86405768.10126582 | 86761472.0 | 87896064.0 | 89362432.0 | bytes |
| network_rx_bytes | available | 158 | — | — | — | — | bytes |
| network_tx_bytes | available | 158 | — | — | — | — | bytes |
| disk_read_bytes | available | 158 | — | — | — | — | bytes |
| disk_write_bytes | available | 158 | — | — | — | — | bytes |
| fd_count | available | 158 | 28.759493670886076 | 28.0 | 30.0 | 30.0 | fds |
| threads | available | 158 | 30.272151898734176 | 30.0 | 31.0 | 32.0 | threads |
| container_memory_bytes | available | 158 | 70504457.90506329 | 73159147.0 | 74511810.0 | 76944506.0 | bytes |
| container_tasks | available | 158 | 32.18987341772152 | 32.0 | 33.0 | 34.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
