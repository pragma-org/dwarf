# DWARF measurement report

Scenario: amaru-measurement-e2e-stock-portable
Duration: 12.809962505 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 7 | 34.285714285714285 | 35.0 | 43.0 | 43.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 7 | 642.5714285714286 | 687.0 | 825.0 | 825.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 7 | 1975.857142857143 | 1938.0 | 3022.0 | 3022.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | unavailable | 0 | — | — | — | — | us |
  - transfer_validation: no completed stock telemetry span was exported for transaction-validation
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 7 | 4.571428571428571 | 5.0 | 6.0 | 6.0 | us |
| block_application | available | 7 | 100.57142857142857 | 101.0 | 135.0 | 135.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | unavailable | 0 | — | — | — | — | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 7 | 1.5357142857142858 | 1.69 | 2.89 | 2.89 | % |
| cpu_time_seconds | unavailable | 0 | — | — | — | — | s |
  - cpu_time_seconds: at least two monotonic counter samples are required
| rss_bytes | unavailable | 0 | — | — | — | — | bytes |
| network_rx_bytes | available | 0 | — | — | — | — | bytes |
| network_tx_bytes | available | 0 | — | — | — | — | bytes |
| disk_read_bytes | available | 0 | — | — | — | — | bytes |
| disk_write_bytes | available | 0 | — | — | — | — | bytes |
| fd_count | unavailable | 0 | — | — | — | — | fds |
| threads | unavailable | 0 | — | — | — | — | threads |
| container_memory_bytes | available | 7 | 57475446.14285714 | 57503907.0 | 57849937.0 | 57849937.0 | bytes |
| container_tasks | available | 7 | 28.0 | 28.0 | 28.0 | 28.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
| attempt_latency | available | 100 | 100269.09 | 101170.0 | 102108.0 | 102343.0 | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
