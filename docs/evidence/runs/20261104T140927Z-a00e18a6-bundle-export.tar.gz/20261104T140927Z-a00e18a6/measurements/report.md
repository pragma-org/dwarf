# DWARF measurement report

Scenario: amaru-measurement-workload-stock-portable
Duration: 868.460412555 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 360 | 23604.161111111112 | 35.0 | 68.0 | 488730.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 360 | 881.7861111111112 | 722.0 | 1917.0 | 2840.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 360 | 2806.0805555555557 | 2376.0 | 4626.0 | 13892.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 12 | 4279.583333333333 | 2113.5 | 17985.0 | 17985.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 80 | 0.5 | 0.5 | 1.0 | 1.0 | tx |
| mempool_size_bytes | available | 80 | 166.125 | 142.5 | 381.0 | 381.0 | bytes |
| mempool_terminal_latency | available | 80 | 1153318.3375 | 34587.5 | 4555275.0 | 10528734.0 | us |
| transfer_validation | available | 42 | 243.61904761904762 | 208.5 | 439.0 | 739.0 | us |
| virtual_machine_acquire_arena | available | 40 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 40 | 3.725 | 3.0 | 6.0 | 12.0 | us |
| virtual_machine_build_program | available | 40 | 29.35 | 27.0 | 44.0 | 63.0 | us |
| virtual_machine_evaluate | available | 40 | 23.525 | 20.5 | 38.0 | 87.0 | us |
| block_prepare | available | 368 | 6.103260869565218 | 5.0 | 9.0 | 21.0 | us |
| block_application | available | 348 | 132.9655172413793 | 120.0 | 175.0 | 350.0 | us |
| epoch_transition | available | 4 | 15430.75 | 11849.5 | 28467.0 | 28467.0 | us |
| keepalive_round_trip | available | 29 | 665.4827586206897 | 623.0 | 1159.0 | 1197.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 336 | 0.41276807142604965 | 0.3881094161880916 | 1.1583082231953359 | 1.553493598873119 | % |
| cpu_time_seconds | available | 338 | — | — | — | — | s |
| rss_bytes | available | 338 | 82808117.01775149 | 82964480.0 | 83767296.0 | 83910656.0 | bytes |
| network_rx_bytes | available | 338 | — | — | — | — | bytes |
| network_tx_bytes | available | 338 | — | — | — | — | bytes |
| disk_read_bytes | available | 338 | — | — | — | — | bytes |
| disk_write_bytes | available | 338 | — | — | — | — | bytes |
| fd_count | available | 338 | 29.153846153846153 | 29.0 | 31.0 | 31.0 | fds |
| threads | available | 338 | 28.011834319526628 | 28.0 | 28.0 | 29.0 | threads |
| container_memory_bytes | available | 338 | 57769463.863905326 | 57923338.0 | 58772684.0 | 58856570.0 | bytes |
| container_tasks | available | 338 | 28.011834319526628 | 28.0 | 28.0 | 29.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 122 | — | — | — | — | operations |
| attempt_latency | available | 121 | 718542.3575289255 | 101141.0 | 4169152.89 | 8797292.287 | us |
| submit_to_protocol_response | available | 21 | 645539.3884761905 | 648277.952 | 693573.34 | 717648.028 | us |
| submit_to_mempool_visibility | available | 20 | 161095.552 | 161131.213 | 168868.462 | 168972.187 | us |
| submit_to_block_inclusion | available | 20 | 3813942.34435 | 3091738.114 | 8797292.287 | 12198105.874 | us |
| submit_to_chain_adoption | available | 20 | 3813942.34435 | 3091738.114 | 8797292.287 | 12198105.874 | us |
| header_validation | available | 0 | — | — | — | — | count |
