# DWARF measurement report

Scenario: ledger-submit-transaction-array-arity-differential-amaru-cardano-node
Duration: 18.342104181 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 3 | 1749.3333333333333 | 1520.0 | 2288.0 | 2288.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 3 | 699.6666666666666 | 439.0 | 1240.0 | 1240.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 3 | 3137.0 | 2490.0 | 4442.0 | 4442.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 1 | 1.0 | 1.0 | 1.0 | 1.0 | tx |
| mempool_size_bytes | available | 1 | 238.0 | 238.0 | 238.0 | 238.0 | bytes |
| mempool_terminal_latency | available | 1 | 694.0 | 694.0 | 694.0 | 694.0 | us |
| transfer_validation | available | 1 | 128.0 | 128.0 | 128.0 | 128.0 | us |
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 3 | 6.333333333333333 | 6.0 | 7.0 | 7.0 | us |
| block_application | available | 3 | 136.66666666666666 | 107.0 | 210.0 | 210.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | available | 1 | 476.0 | 476.0 | 476.0 | 476.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 9 | 0.15994333859258317 | 0.0 | 0.48056216420400527 | 0.48056216420400527 | % |
| cpu_time_seconds | available | 10 | — | — | — | — | s |
| rss_bytes | available | 10 | 90842726.4 | 91092992.0 | 91136000.0 | 91136000.0 | bytes |
| network_rx_bytes | available | 10 | — | — | — | — | bytes |
| network_tx_bytes | available | 10 | — | — | — | — | bytes |
| disk_read_bytes | available | 10 | — | — | — | — | bytes |
| disk_write_bytes | available | 10 | — | — | — | — | bytes |
| fd_count | available | 10 | 28.0 | 28.0 | 28.0 | 28.0 | fds |
| threads | available | 10 | 30.4 | 30.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 10 | 71422705.2 | 71408025.0 | 71638712.0 | 71638712.0 | bytes |
| container_tasks | available | 10 | 32.4 | 32.0 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
