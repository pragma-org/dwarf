# DWARF measurement report

Scenario: cbor-strictness-witness-arity-vkey-noncurve-differential-amaru-cardano-node
Duration: 10.70365541 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 2 | 1702.5 | 1702.5 | 1888.0 | 1888.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 2 | 468.5 | 468.5 | 498.0 | 498.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 2 | 2603.5 | 2603.5 | 2793.0 | 2793.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | unavailable | 0 | — | — | — | — | us |
  - transfer_validation: no completed stock telemetry span was exported for transaction-validation
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 2 | 3.0 | 3.0 | 3.0 | 3.0 | us |
| block_application | available | 2 | 83.5 | 83.5 | 87.0 | 87.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | unavailable | 0 | — | — | — | — | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 6 | 0.15973914891912055 | 0.0 | 0.47968892211501096 | 0.47968892211501096 | % |
| cpu_time_seconds | available | 7 | — | — | — | — | s |
| rss_bytes | available | 7 | 89738093.71428572 | 89718784.0 | 89853952.0 | 89853952.0 | bytes |
| network_rx_bytes | available | 7 | — | — | — | — | bytes |
| network_tx_bytes | available | 7 | — | — | — | — | bytes |
| disk_read_bytes | available | 7 | — | — | — | — | bytes |
| disk_write_bytes | available | 7 | — | — | — | — | bytes |
| fd_count | available | 7 | 29.0 | 29.0 | 29.0 | 29.0 | fds |
| threads | available | 7 | 30.142857142857142 | 30.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 7 | 73265502.57142857 | 73589063.0 | 74228695.0 | 74228695.0 | bytes |
| container_tasks | available | 7 | 32.142857142857146 | 32.0 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
