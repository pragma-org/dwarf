# DWARF measurement report

Scenario: client-example-simple-transfer-amaru-portable-20260918
Duration: 211.863603944 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 79 | 1352.367088607595 | 1186.0 | 2404.0 | 4501.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 79 | 1331.8354430379748 | 984.0 | 3191.0 | 8355.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 79 | 5135.2405063291135 | 3271.0 | 12268.0 | 63613.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | available | 30 | 157.23333333333332 | 160.0 | 198.0 | 206.0 | us |
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 79 | 15.556962025316455 | 6.0 | 9.0 | 731.0 | us |
| block_application | available | 79 | 155.98973417721518 | 146.961 | 338.148 | 483.575 | us |
| epoch_transition | available | 1 | 8149.0 | 8149.0 | 8149.0 | 8149.0 | us |
| keepalive_round_trip | available | 7 | 537.7142857142857 | 475.0 | 1084.0 | 1084.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 106 | 0.3431274674412383 | 0.48790895765328557 | 0.9979570636346126 | 1.0005341781997281 | % |
| cpu_time_seconds | available | 107 | — | — | — | — | s |
| rss_bytes | available | 107 | 105647821.75700934 | 105521152.0 | 105783296.0 | 105803776.0 | bytes |
| network_rx_bytes | available | 107 | — | — | — | — | bytes |
| network_tx_bytes | available | 107 | — | — | — | — | bytes |
| disk_read_bytes | available | 107 | — | — | — | — | bytes |
| disk_write_bytes | available | 107 | — | — | — | — | bytes |
| fd_count | available | 107 | 27.50467289719626 | 27.0 | 28.0 | 28.0 | fds |
| threads | available | 107 | 28.0 | 28.0 | 28.0 | 28.0 | threads |
| container_memory_bytes | available | 107 | 113843993.91588785 | 113875353.0 | 114085068.0 | 114085068.0 | bytes |
| container_tasks | available | 107 | 28.0 | 28.0 | 28.0 | 28.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 1 | — | — | — | — | operations |
| attempt_latency | available | 35 | 3126564.6694857143 | 2644877.395 | 9930910.123 | 12297229.946 | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | available | 30 | 2826912.5206 | 1964188.196 | 9204239.641 | 11599729.478 | us |
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_decode | available | 631 | 1.4461156893819336 | 1.072 | 5.02 | 5.801 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 631 | 1.900488114104596 | 1.252 | 6.142 | 7.344 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | unavailable | 0 | — | — | — | — | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | unavailable | 0 | — | — | — | — | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | unavailable | 0 | — | — | — | — | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| handler | available | 395 | 29.2817417721519 | 21.701 | 59.594 | 93.609 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 79 | 2.8495696202531646 | 2.815 | 4.388 | 5.581 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 395 | 0.8 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 395 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | unavailable | 0 | — | — | — | — | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | unavailable | 0 | — | — | — | — | us |
| body_to_terminal | unavailable | 0 | — | — | — | — | us |
| amaru-patched-txsubmission-residence.pending_depth | unavailable | 0 | — | — | — | — | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | unavailable | 0 | — | — | — | — | transactions |
| unacked_depth | unavailable | 0 | — | — | — | — | transactions |
| blocking_residence | unavailable | 0 | — | — | — | — | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
