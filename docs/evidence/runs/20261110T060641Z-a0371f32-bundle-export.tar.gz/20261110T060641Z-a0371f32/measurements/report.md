# DWARF measurement report

Scenario: ledger-block-apply-isvalid-false-donation-value-creation-amaru-cardano-node
Duration: 296.394898715 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 103 | 798.9029126213592 | 674.0 | 1542.0 | 1760.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 103 | 64332.18446601942 | 81675.0 | 83458.0 | 83606.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 119 | 60115.6974789916 | 83244.0 | 85579.0 | 103114.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | available | 3 | 282.6666666666667 | 257.0 | 449.0 | 449.0 | us |
| virtual_machine_acquire_arena | available | 1 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 1 | 13.0 | 13.0 | 13.0 | 13.0 | us |
| virtual_machine_build_program | available | 1 | 31.0 | 31.0 | 31.0 | 31.0 | us |
| virtual_machine_evaluate | available | 1 | 42.0 | 42.0 | 42.0 | 42.0 | us |
| block_prepare | available | 127 | 8.543307086614174 | 7.0 | 16.0 | 25.0 | us |
| block_application | available | 103 | 143.126213592233 | 143.0 | 232.0 | 245.0 | us |
| epoch_transition | available | 2 | 9994.5 | 9994.5 | 10591.0 | 10591.0 | us |
| keepalive_round_trip | available | 11 | 2711.818181818182 | 2879.0 | 3364.0 | 3364.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 8 | 0.23995127870987737 | 0.0 | 0.9600368021052378 | 0.9600368021052378 | % |
| cpu_time_seconds | available | 9 | — | — | — | — | s |
| rss_bytes | available | 9 | 71806065.77777778 | 71925760.0 | 71983104.0 | 71983104.0 | bytes |
| network_rx_bytes | available | 10 | — | — | — | — | bytes |
| network_tx_bytes | available | 10 | — | — | — | — | bytes |
| disk_read_bytes | available | 10 | — | — | — | — | bytes |
| disk_write_bytes | available | 10 | — | — | — | — | bytes |
| fd_count | available | 9 | 29.0 | 29.0 | 29.0 | 29.0 | fds |
| threads | available | 9 | 30.555555555555557 | 31.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 10 | 45120224.8 | 50053775.0 | 50342133.0 | 50342133.0 | bytes |
| container_tasks | available | 10 | 29.3 | 32.5 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
