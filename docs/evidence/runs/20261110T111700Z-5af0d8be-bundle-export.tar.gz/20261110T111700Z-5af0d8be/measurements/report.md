# DWARF measurement report

Scenario: runtime-substrate-txsubmission-unexpected-body-mixed-amaru
Duration: 13.29000315 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | unavailable | 0 | — | — | — | — | us |
  - blockfetch_duration: the node traced no BlockFetch.Client record in this window (namespace not enabled, or silent)
| blockfetch_bytes | unavailable | 0 | — | — | — | — | bytes |
  - blockfetch_bytes: the node traced no BlockFetch.Client record in this window (namespace not enabled, or silent); a zero would not be a reading
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | unavailable | 0 | — | — | — | — | transactions |
  - mempool_tx_count: Mempool records were traced but none carried a sample
| mempool_bytes | unavailable | 0 | — | — | — | — | bytes |
  - mempool_bytes: Mempool records were traced but none carried a sample
| mempool_sync_duration | available | 1 | 475.781 | 475.781 | 475.781 | 475.781 | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 2 | 702.0 | 702.0 | 842.0 | 842.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 7 | 0.6147735714264071 | 0.47816620665056864 | 1.4332979932639809 | 1.4332979932639809 | % |
| cpu_time_seconds | available | 8 | — | — | — | — | s |
| rss_bytes | available | 8 | 146931712.0 | 146845696.0 | 147189760.0 | 147189760.0 | bytes |
| network_rx_bytes | available | 8 | — | — | — | — | bytes |
| network_tx_bytes | available | 8 | — | — | — | — | bytes |
| disk_read_bytes | available | 8 | — | — | — | — | bytes |
| disk_write_bytes | available | 8 | — | — | — | — | bytes |
| fd_count | available | 8 | 25.25 | 26.0 | 26.0 | 26.0 | fds |
| threads | available | 8 | 10.25 | 10.0 | 11.0 | 11.0 | threads |
| container_memory_bytes | available | 8 | 84415610.375 | 83907051.0 | 87933583.0 | 87933583.0 | bytes |
| container_tasks | available | 8 | 13.0 | 12.0 | 18.0 | 18.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
