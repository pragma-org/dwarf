# DWARF measurement report

Scenario: runtime-substrate-blockfetch-continuity-failure-example-smoke
Duration: 37.001282988 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 4 | 195032.4495 | 20389.783 | 736063.733 | 736063.733 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | unavailable | 0 | — | — | — | — | transactions |
  - mempool_tx_count: Mempool records were traced but none carried a sample
| mempool_bytes | unavailable | 0 | — | — | — | — | bytes |
  - mempool_bytes: Mempool records were traced but none carried a sample
| mempool_sync_duration | available | 19 | 156.76784210526316 | 146.57 | 278.64300000000003 | 278.64300000000003 | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 3 | 1333.6666666666667 | 1615.0 | 1970.0 | 1970.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 17 | 1.7754283844679961 | 1.910087729367504 | 2.389427077082771 | 2.389427077082771 | % |
| cpu_time_seconds | available | 19 | — | — | — | — | s |
| rss_bytes | available | 19 | 115220695.57894737 | 114823168.0 | 117981184.0 | 117981184.0 | bytes |
| network_rx_bytes | available | 19 | — | — | — | — | bytes |
| network_tx_bytes | available | 19 | — | — | — | — | bytes |
| disk_read_bytes | available | 19 | — | — | — | — | bytes |
| disk_write_bytes | available | 19 | — | — | — | — | bytes |
| fd_count | available | 19 | 23.57894736842105 | 23.0 | 25.0 | 25.0 | fds |
| threads | available | 19 | 11.368421052631579 | 11.0 | 12.0 | 12.0 | threads |
| container_memory_bytes | available | 19 | 51806828.421052635 | 51568967.0 | 54284779.0 | 54284779.0 | bytes |
| container_tasks | available | 19 | 13.368421052631579 | 13.0 | 14.0 | 14.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| header_validation | available | 0 | — | — | — | — | count |
