# DWARF measurement report

Scenario: amaru-measurement-workload-stock-portable
Duration: 486.138115142 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 205 | 83135.23414634146 | 36.0 | 115.0 | 2497114.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 205 | 1045.1463414634147 | 878.0 | 2079.0 | 2832.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 205 | 6923.463414634146 | 3298.0 | 19912.0 | 40491.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 8 | 10758.375 | 7547.0 | 38157.0 | 38157.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 80 | 0.5 | 0.5 | 1.0 | 1.0 | tx |
| mempool_size_bytes | available | 80 | 166.125 | 142.5 | 381.0 | 381.0 | bytes |
| mempool_terminal_latency | available | 80 | 1029657.575 | 11984.0 | 4528792.0 | 9810740.0 | us |
| transfer_validation | available | 40 | 242.95 | 212.5 | 406.0 | 482.0 | us |
| virtual_machine_acquire_arena | available | 40 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 40 | 3.6 | 3.0 | 7.0 | 8.0 | us |
| virtual_machine_build_program | available | 40 | 33.0 | 31.5 | 51.0 | 55.0 | us |
| virtual_machine_evaluate | available | 40 | 24.175 | 22.0 | 38.0 | 54.0 | us |
| block_prepare | available | 213 | 5.657276995305164 | 5.0 | 10.0 | 15.0 | us |
| block_application | available | 197 | 126.9281116751269 | 121.663 | 183.822 | 216.434 | us |
| epoch_transition | available | 3 | 14114.333333333334 | 9645.0 | 25000.0 | 25000.0 | us |
| keepalive_round_trip | available | 16 | 725.6875 | 585.0 | 1136.0 | 1136.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 193 | 0.47818652849740934 | 0.23 | 1.31 | 2.88 | % |
| cpu_time_seconds | unavailable | 0 | — | — | — | — | s |
  - cpu_time_seconds: at least two monotonic counter samples are required
| rss_bytes | unavailable | 0 | — | — | — | — | bytes |
| network_rx_bytes | unavailable | 0 | — | — | — | — | bytes |
  - network_rx_bytes: counter reset or non-positive sample duration
| network_tx_bytes | unavailable | 0 | — | — | — | — | bytes |
  - network_tx_bytes: counter reset or non-positive sample duration
| disk_read_bytes | available | 0 | — | — | — | — | bytes |
| disk_write_bytes | unavailable | 0 | — | — | — | — | bytes |
  - disk_write_bytes: counter reset or non-positive sample duration
| fd_count | unavailable | 0 | — | — | — | — | fds |
| threads | unavailable | 0 | — | — | — | — | threads |
| container_memory_bytes | available | 193 | 74553264.13471502 | 76042731.0 | 77259079.0 | 77521223.0 | bytes |
| container_tasks | available | 193 | 28.025906735751295 | 28.0 | 28.0 | 29.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
| attempt_latency | available | 120 | 609170.6198333333 | 101363.0 | 3055204.439 | 6418001.16 | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | available | 20 | 3153643.069 | 2598577.7835 | 6418001.16 | 7703891.396 | us |
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_decode | available | 1000 | 2.8287970000000002 | 1.5379999999999998 | 6.653 | 25.378 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 1000 | 3.6055639999999998 | 2.214 | 8.587 | 26.861 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | available | 101 | 2.3359702970297027 | 2.094 | 4.429 | 6.112 | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | available | 101 | 3.0178811881188117 | 2.875 | 5.25 | 7.595 | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | available | 68 | 0.7840588235294118 | 0.6910000000000001 | 1.814 | 2.835 | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| handler | available | 1006 | 27.319501988071572 | 21.225 | 68.492 | 123.577 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 205 | 2.4645560975609757 | 2.204 | 4.178 | 10.8 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 1006 | 0.8001988071570576 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 1006 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | available | 40 | 972.1873250000001 | 949.2115 | 1254.41 | 1374.16 | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | available | 40 | 374.246975 | 379.872 | 440.443 | 472.263 | us |
| body_to_terminal | available | 40 | 597.9403500000001 | 560.9535 | 900.663 | 950.98 | us |
| amaru-patched-txsubmission-residence.pending_depth | available | 120 | 0.3333333333333333 | 0.0 | 1.0 | 1.0 | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | available | 120 | 0.3333333333333333 | 0.0 | 1.0 | 1.0 | transactions |
| unacked_depth | available | 120 | 1.0 | 1.0 | 1.0 | 1.0 | transactions |
| blocking_residence | available | 40 | 14311537.268099999 | 4986251.081 | 9746385.315 | 364220433.923 | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_validation | available | 0 | — | — | — | — | count |
