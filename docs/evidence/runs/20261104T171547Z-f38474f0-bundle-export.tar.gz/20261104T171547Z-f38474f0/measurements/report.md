# DWARF measurement report

Scenario: cardano-measurement-workload-stock-portable
Duration: 296.490526709 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 73 | 4218.156287671232 | 4167.981000000001 | 5156.494000000001 | 5715.352 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | available | 81 | 0.49382716049382713 | 0.0 | 1.0 | 1.0 | transactions |
| mempool_bytes | available | 81 | 164.69135802469137 | 0.0 | 385.0 | 385.0 | bytes |
| mempool_sync_duration | unavailable | 0 | — | — | — | — | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 46 | 584.804347826087 | 530.5 | 1008.0 | 1063.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 114 | 2.0443444208237684 | 1.930151157339875 | 2.705872568514472 | 3.083491887361443 | % |
| cpu_time_seconds | available | 116 | — | — | — | — | s |
| rss_bytes | available | 116 | 163621640.8275862 | 165412864.0 | 165707776.0 | 165715968.0 | bytes |
| network_rx_bytes | available | 116 | — | — | — | — | bytes |
| network_tx_bytes | available | 116 | — | — | — | — | bytes |
| disk_read_bytes | available | 116 | — | — | — | — | bytes |
| disk_write_bytes | available | 116 | — | — | — | — | bytes |
| fd_count | available | 116 | 25.336206896551722 | 24.0 | 30.0 | 34.0 | fds |
| threads | available | 116 | 11.96551724137931 | 12.0 | 12.0 | 12.0 | threads |
| container_memory_bytes | available | 116 | 83953604.1724138 | 89113231.0 | 89768591.0 | 89821020.0 | bytes |
| container_tasks | available | 116 | 13.844827586206897 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 245 | — | — | — | — | operations |
| attempt_latency | available | 122 | 409681.8807459016 | 194.5 | 2697443.018 | 4413770.783 | us |
| submit_to_protocol_response | available | 11 | 343672.23699999996 | 338028.852 | 381864.093 | 381864.093 | us |
| submit_to_mempool_visibility | available | 11 | 165060.49336363637 | 165235.613 | 176328.019 | 176328.019 | us |
| submit_to_block_inclusion | available | 20 | 2461049.7146 | 2657373.4170000004 | 4413770.783 | 5230350.617 | us |
| submit_to_chain_adoption | available | 10 | 3206829.2569 | 2735765.6385000004 | 5230350.617 | 5230350.617 | us |
| header_validation | available | 0 | — | — | — | — | count |
