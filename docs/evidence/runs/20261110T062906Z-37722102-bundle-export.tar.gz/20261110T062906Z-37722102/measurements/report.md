# DWARF measurement report

Scenario: ledger-submit-inline-datum-tag24-trailing-differential-amaru-cardano-node
Duration: 142.321476841 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 6 | 1788.6666666666667 | 1587.0 | 2388.0 | 2388.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 6 | 599.6666666666666 | 471.5 | 1283.0 | 1283.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 6 | 2996.8333333333335 | 2644.0 | 4674.0 | 4674.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 3 | 0.6666666666666666 | 1.0 | 1.0 | 1.0 | tx |
| mempool_size_bytes | available | 3 | 137.0 | 205.0 | 206.0 | 206.0 | bytes |
| mempool_terminal_latency | available | 4 | 2104359.0 | 530.0 | 8415933.0 | 8415933.0 | us |
| transfer_validation | available | 3 | 126.66666666666667 | 125.0 | 145.0 | 145.0 | us |
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 6 | 6.333333333333333 | 4.0 | 18.0 | 18.0 | us |
| block_application | available | 6 | 102.16666666666667 | 92.0 | 168.0 | 168.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | available | 5 | 471.0 | 417.0 | 716.0 | 716.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 69 | 0.18100384770489739 | 0.0 | 0.4807125011222409 | 0.9562912547745904 | % |
| cpu_time_seconds | available | 70 | — | — | — | — | s |
| rss_bytes | available | 70 | 87810048.0 | 87547904.0 | 89432064.0 | 89464832.0 | bytes |
| network_rx_bytes | available | 70 | — | — | — | — | bytes |
| network_tx_bytes | available | 70 | — | — | — | — | bytes |
| disk_read_bytes | available | 70 | — | — | — | — | bytes |
| disk_write_bytes | available | 70 | — | — | — | — | bytes |
| fd_count | available | 70 | 28.0 | 28.0 | 28.0 | 28.0 | fds |
| threads | available | 70 | 30.357142857142858 | 30.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 70 | 68683375.28571428 | 67853352.0 | 70988595.0 | 71020052.0 | bytes |
| container_tasks | available | 70 | 32.357142857142854 | 32.0 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
