# DWARF measurement report

Scenario: amaru-measurement-workload-stock-portable
Duration: 851.928335624 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 372 | 36270.30376344086 | 1159.5 | 3082.0 | 1497916.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 372 | 1537.7016129032259 | 943.0 | 4664.0 | 8863.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 381 | 265527.10498687666 | 3171.0 | 49420.0 | 17000339.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 14 | 2677.214285714286 | 2324.5 | 6466.0 | 6466.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 80 | 0.5 | 0.5 | 1.0 | 1.0 | tx |
| mempool_size_bytes | available | 80 | 166.125 | 142.5 | 381.0 | 381.0 | bytes |
| mempool_terminal_latency | available | 80 | 1145668.0625 | 22819.5 | 4558998.0 | 7347778.0 | us |
| transfer_validation | available | 41 | 312.5853658536585 | 222.0 | 732.0 | 1876.0 | us |
| virtual_machine_acquire_arena | available | 41 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 41 | 4.2682926829268295 | 4.0 | 7.0 | 10.0 | us |
| virtual_machine_build_program | available | 41 | 35.8780487804878 | 33.0 | 69.0 | 92.0 | us |
| virtual_machine_evaluate | available | 41 | 24.634146341463413 | 24.0 | 36.0 | 38.0 | us |
| block_prepare | available | 382 | 12.180628272251308 | 6.0 | 10.0 | 29.0 | us |
| block_application | available | 360 | 139.525 | 132.0 | 189.0 | 505.0 | us |
| epoch_transition | available | 4 | 9753.25 | 9929.0 | 10894.0 | 10894.0 | us |
| keepalive_round_trip | available | 29 | 540.6896551724138 | 488.0 | 842.0 | 911.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 408 | 0.4673137356865902 | 0.47921827595562255 | 0.9615027697362671 | 3.8439549593288533 | % |
| cpu_time_seconds | available | 410 | — | — | — | — | s |
| rss_bytes | available | 410 | 72623758.36097561 | 72839168.0 | 73547776.0 | 73641984.0 | bytes |
| network_rx_bytes | available | 410 | — | — | — | — | bytes |
| network_tx_bytes | available | 410 | — | — | — | — | bytes |
| disk_read_bytes | available | 410 | — | — | — | — | bytes |
| disk_write_bytes | available | 410 | — | — | — | — | bytes |
| fd_count | available | 410 | 29.151219512195123 | 29.0 | 31.0 | 31.0 | fds |
| threads | available | 410 | 29.965853658536584 | 30.0 | 30.0 | 30.0 | threads |
| container_memory_bytes | available | 410 | 61456348.34878049 | 51291094.5 | 76766248.0 | 77007421.0 | bytes |
| container_tasks | available | 410 | 29.93658536585366 | 30.0 | 30.0 | 30.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 243 | — | — | — | — | operations |
| attempt_latency | available | 121 | 689469.8944545455 | 101262.0 | 4582756.768 | 5841554.459 | us |
| submit_to_protocol_response | available | 21 | 723693.1977619048 | 721153.003 | 765290.297 | 781500.651 | us |
| submit_to_mempool_visibility | available | 20 | 169257.4308 | 167080.715 | 186199.36 | 191938.951 | us |
| submit_to_block_inclusion | available | 20 | 3635911.9204499996 | 3389622.974 | 5841554.459 | 8395965.748 | us |
| submit_to_chain_adoption | available | 20 | 3635911.9204499996 | 3389622.974 | 5841554.459 | 8395965.748 | us |
| header_validation | available | 0 | — | — | — | — | count |
