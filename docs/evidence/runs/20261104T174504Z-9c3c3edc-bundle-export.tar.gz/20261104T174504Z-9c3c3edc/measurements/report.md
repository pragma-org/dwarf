# DWARF measurement report

Scenario: cardano-measurement-workload-stock-portable
Duration: 324.145936218 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 77 | 4532.645805194806 | 4371.192 | 5491.579 | 12739.496 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | available | 81 | 0.49382716049382713 | 0.0 | 1.0 | 1.0 | transactions |
| mempool_bytes | available | 81 | 164.69135802469137 | 0.0 | 385.0 | 385.0 | bytes |
| mempool_sync_duration | unavailable | 0 | — | — | — | — | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 48 | 755.1875 | 672.0 | 1263.0 | 1512.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 124 | 2.1729745484152487 | 1.9302888100693085 | 3.0729555711938055 | 3.4631731126590766 | % |
| cpu_time_seconds | available | 126 | — | — | — | — | s |
| rss_bytes | available | 126 | 169987933.46031746 | 170729472.0 | 173723648.0 | 173723648.0 | bytes |
| network_rx_bytes | available | 126 | — | — | — | — | bytes |
| network_tx_bytes | available | 126 | — | — | — | — | bytes |
| disk_read_bytes | available | 126 | — | — | — | — | bytes |
| disk_write_bytes | available | 126 | — | — | — | — | bytes |
| fd_count | available | 126 | 27.206349206349206 | 26.0 | 33.0 | 34.0 | fds |
| threads | available | 126 | 11.920634920634921 | 12.0 | 12.0 | 12.0 | threads |
| container_memory_bytes | available | 126 | 68218772.85714285 | 68713185.0 | 71617740.0 | 71712112.0 | bytes |
| container_tasks | available | 126 | 14.007936507936508 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 245 | — | — | — | — | operations |
| attempt_latency | available | 122 | 483735.70459016395 | 183.0 | 2714714.933 | 6873148.66 | us |
| submit_to_protocol_response | available | 11 | 342641.515 | 344097.901 | 362746.412 | 362746.412 | us |
| submit_to_mempool_visibility | available | 11 | 162771.52327272727 | 164087.947 | 169482.665 | 169482.665 | us |
| submit_to_block_inclusion | available | 20 | 2913966.7292 | 2309454.3225 | 6873148.66 | 11900076.199 | us |
| submit_to_chain_adoption | available | 10 | 3702820.7856 | 2678666.4455 | 11900076.199 | 11900076.199 | us |
| protocol_receive_decode | available | 2266 | 1000451.771321271 | 539.768 | 6596963.719 | 10598482.431 | us |
| protocol_receive_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_application | available | 307 | 66.77398045602607 | 36.931 | 316.175 | 400.246 | us |
| block_application_by_outcome | unavailable | 0 | — | — | — | — | — |
| epoch_transition | available | 19 | 121.55747368421054 | 69.082 | 739.796 | 739.796 | us |
| epoch_transition_by_outcome | unavailable | 0 | — | — | — | — | — |
| plutus_vm | available | 45 | 49.211644444444445 | 51.539 | 76.246 | 86.014 | us |
| plutus_vm_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_validation | available | 0 | — | — | — | — | count |
| cardano-patched-header-validation.header_validation | available | 469 | 359.2560916844349 | 314.722 | 590.34 | 854.626 | us |
| header_validation_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_prerequisite_unavailable | unavailable | 0 | — | — | — | — | us |
| queue_residence_lower_bound | available | 102 | 0.0 | 0.0 | 0.0 | 0.0 | microseconds |
| queue_residence_upper_bound | available | 102 | 60.90372549019608 | 59.884 | 121.452 | 136.17 | microseconds |
| handler_service | available | 102 | 20.045029411764705 | 18.851 | 30.378 | 39.165 | microseconds |
| pending_range_depth | available | 204 | 0.5 | 0.5 | 1.0 | 1.0 | ranges |
| request_to_body_lower_bound | available | 20 | 958.9343500000001 | 825.991 | 1635.26 | 2060.684 | microseconds |
| request_to_body_upper_bound | available | 20 | 995.9995000000001 | 874.5835 | 1665.187 | 2090.621 | microseconds |
| body_to_terminal_lower_bound | available | 20 | 44.9306 | 42.201 | 61.849 | 64.363 | microseconds |
| body_to_terminal_upper_bound | available | 20 | 89.86645 | 82.493 | 121.122 | 123.607 | microseconds |
| request_to_terminal_lower_bound | available | 20 | 1038.30965 | 926.1475 | 1706.256 | 2129.776 | microseconds |
| request_to_terminal_upper_bound | available | 20 | 1051.4212499999999 | 940.2795 | 1717.016 | 2138.693 | microseconds |
| pending_body_depth | available | 60 | 0.3333333333333333 | 0.0 | 1.0 | 1.0 | transactions |
| inflight_body_depth | available | 60 | 0.6666666666666666 | 1.0 | 1.0 | 1.0 | transactions |
