# DWARF measurement report

Scenario: cardano-measurement-workload-stock-portable
Duration: 319.169266031 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 84 | 4558.8239523809525 | 4421.887500000001 | 6097.686 | 8600.925000000001 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | available | 81 | 0.49382716049382713 | 0.0 | 1.0 | 1.0 | transactions |
| mempool_bytes | available | 81 | 164.69135802469137 | 0.0 | 385.0 | 385.0 | bytes |
| mempool_sync_duration | unavailable | 0 | — | — | — | — | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 50 | 570.7 | 512.5 | 1055.0 | 1452.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 122 | 2.0471694790568344 | 1.9283177703769852 | 2.732960808718876 | 3.091971647121124 | % |
| cpu_time_seconds | available | 124 | — | — | — | — | s |
| rss_bytes | available | 124 | 170773669.16129032 | 173365248.0 | 173846528.0 | 173850624.0 | bytes |
| network_rx_bytes | available | 124 | — | — | — | — | bytes |
| network_tx_bytes | available | 124 | — | — | — | — | bytes |
| disk_read_bytes | available | 124 | — | — | — | — | bytes |
| disk_write_bytes | available | 124 | — | — | — | — | bytes |
| fd_count | available | 124 | 27.201612903225808 | 26.0 | 32.0 | 34.0 | fds |
| threads | available | 124 | 11.887096774193548 | 12.0 | 12.0 | 12.0 | threads |
| container_memory_bytes | available | 124 | 69082723.27419356 | 71811727.0 | 72288829.0 | 72687288.0 | bytes |
| container_tasks | available | 124 | 13.887096774193548 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 245 | — | — | — | — | operations |
| attempt_latency | available | 122 | 523222.5180573771 | 176.0 | 4426090.091 | 6137031.775 | us |
| submit_to_protocol_response | available | 11 | 340440.3833636364 | 345606.373 | 363800.614 | 363800.614 | us |
| submit_to_mempool_visibility | available | 11 | 159806.23072727275 | 156470.383 | 175079.049 | 175079.049 | us |
| submit_to_block_inclusion | available | 20 | 3155721.02465 | 2724575.4495 | 6137031.775 | 8694325.702 | us |
| submit_to_chain_adoption | available | 10 | 3408683.3794 | 2330257.957 | 8694325.702 | 8694325.702 | us |
| protocol_receive_decode | available | 2333 | 968763.8180775824 | 490.739 | 6658913.159 | 10600591.105 | us |
| protocol_receive_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_application | available | 310 | 68.5018193548387 | 35.663 | 347.545 | 390.457 | us |
| block_application_by_outcome | unavailable | 0 | — | — | — | — | — |
| epoch_transition | available | 12 | 122.00616666666667 | 122.91550000000001 | 215.612 | 215.612 | us |
| epoch_transition_by_outcome | unavailable | 0 | — | — | — | — | — |
| plutus_vm | available | 46 | 49.87984782608696 | 52.786 | 67.239 | 74.783 | us |
| plutus_vm_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_validation | available | 0 | — | — | — | — | count |
| cardano-patched-header-validation.header_validation | available | 483 | 347.57783850931673 | 314.693 | 526.929 | 787.076 | us |
| header_validation_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_prerequisite_unavailable | unavailable | 0 | — | — | — | — | us |
| queue_residence_lower_bound | available | 107 | 0.0 | 0.0 | 0.0 | 0.0 | microseconds |
| queue_residence_upper_bound | available | 107 | 58.89327102803738 | 34.175 | 141.611 | 187.148 | microseconds |
| handler_service | available | 107 | 20.518915887850465 | 18.966 | 32.712 | 44.755 | microseconds |
| pending_range_depth | available | 214 | 0.5 | 0.5 | 1.0 | 1.0 | ranges |
| request_to_body_lower_bound | available | 20 | 730.79815 | 645.3154999999999 | 1069.568 | 1468.712 | microseconds |
| request_to_body_upper_bound | available | 20 | 770.205 | 687.8119999999999 | 1102.691 | 1505.341 | microseconds |
| body_to_terminal_lower_bound | available | 20 | 49.65565 | 44.4705 | 77.118 | 80.825 | microseconds |
| body_to_terminal_upper_bound | available | 20 | 99.73395000000001 | 92.713 | 143.114 | 149.215 | microseconds |
| request_to_terminal_lower_bound | available | 20 | 816.90305 | 754.9549999999999 | 1135.624 | 1547.433 | microseconds |
| request_to_terminal_upper_bound | available | 20 | 833.4897000000001 | 773.8365 | 1149.541 | 1562.932 | microseconds |
| pending_body_depth | available | 60 | 0.3333333333333333 | 0.0 | 1.0 | 1.0 | transactions |
| inflight_body_depth | available | 60 | 0.6666666666666666 | 1.0 | 1.0 | 1.0 | transactions |
