# DWARF measurement report

Scenario: cardano-measurement-workload-stock-portable
Duration: 293.349206595 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 79 | 4469.705151898734 | 4304.916 | 5987.631 | 7987.251000000001 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | available | 81 | 0.49382716049382713 | 0.0 | 1.0 | 1.0 | transactions |
| mempool_bytes | available | 81 | 164.69135802469137 | 0.0 | 385.0 | 385.0 | bytes |
| mempool_sync_duration | unavailable | 0 | — | — | — | — | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 42 | 585.2380952380952 | 451.5 | 1018.0 | 1147.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 113 | 2.087530028161141 | 1.9315999204449943 | 3.0827572920013715 | 3.087077337986192 | % |
| cpu_time_seconds | available | 115 | — | — | — | — | s |
| rss_bytes | available | 115 | 167975214.7478261 | 170184704.0 | 170319872.0 | 170356736.0 | bytes |
| network_rx_bytes | available | 115 | — | — | — | — | bytes |
| network_tx_bytes | available | 115 | — | — | — | — | bytes |
| disk_read_bytes | available | 115 | — | — | — | — | bytes |
| disk_write_bytes | available | 115 | — | — | — | — | bytes |
| fd_count | available | 115 | 25.31304347826087 | 24.0 | 30.0 | 34.0 | fds |
| threads | available | 115 | 11.878260869565217 | 12.0 | 12.0 | 12.0 | threads |
| container_memory_bytes | available | 115 | 69254523.55652174 | 71512883.0 | 72058142.0 | 72131543.0 | bytes |
| container_tasks | available | 115 | 13.843478260869565 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | available | 245 | — | — | — | — | operations |
| attempt_latency | available | 122 | 443110.25917213113 | 164.5 | 2748582.372 | 5226041.322 | us |
| submit_to_protocol_response | available | 11 | 342449.0183636364 | 346208.21 | 357705.19 | 357705.19 | us |
| submit_to_mempool_visibility | available | 11 | 166147.2010909091 | 164823.561 | 188550.317 | 188550.317 | us |
| submit_to_block_inclusion | available | 20 | 2666982.8726 | 2683638.9639999997 | 5226041.322 | 6043915.577 | us |
| submit_to_chain_adoption | available | 10 | 3112347.7881 | 2688852.4065 | 6043915.577 | 6043915.577 | us |
| header_validation | available | 0 | — | — | — | — | count |
