# DWARF measurement report

Scenario: plutus-onchain-cek-value-structure-differential-amaru-cardano-node
Duration: 100.889400457 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 6 | 1705.8333333333333 | 1600.0 | 2240.0 | 2240.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 6 | 627.6666666666666 | 554.5 | 1063.0 | 1063.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 6 | 3038.5 | 2696.0 | 4717.0 | 4717.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 5 | 1.4 | 1.0 | 3.0 | 3.0 | tx |
| mempool_size_bytes | available | 5 | 698.6 | 579.0 | 1488.0 | 1488.0 | bytes |
| mempool_terminal_latency | available | 6 | 509765.0 | 802.0 | 3054742.0 | 3054742.0 | us |
| transfer_validation | available | 3 | 185.66666666666666 | 195.0 | 226.0 | 226.0 | us |
| virtual_machine_acquire_arena | available | 7 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 7 | 11.714285714285714 | 11.0 | 20.0 | 20.0 | us |
| virtual_machine_build_program | available | 7 | 34.714285714285715 | 32.0 | 62.0 | 62.0 | us |
| virtual_machine_evaluate | available | 7 | 40.42857142857143 | 50.0 | 64.0 | 64.0 | us |
| block_prepare | available | 6 | 4.666666666666667 | 4.0 | 7.0 | 7.0 | us |
| block_application | available | 6 | 102.83333333333333 | 85.5 | 190.0 | 190.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | available | 3 | 561.3333333333334 | 438.0 | 854.0 | 854.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 49 | 0.2054630170726673 | 0.0 | 0.9598496429652967 | 0.9610663193412422 | % |
| cpu_time_seconds | available | 50 | — | — | — | — | s |
| rss_bytes | available | 50 | 88478679.04 | 87795712.0 | 89423872.0 | 90689536.0 | bytes |
| network_rx_bytes | available | 50 | — | — | — | — | bytes |
| network_tx_bytes | available | 50 | — | — | — | — | bytes |
| disk_read_bytes | available | 50 | — | — | — | — | bytes |
| disk_write_bytes | available | 50 | — | — | — | — | bytes |
| fd_count | available | 50 | 28.0 | 28.0 | 28.0 | 28.0 | fds |
| threads | available | 50 | 30.34 | 30.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 50 | 68828528.18 | 67648880.5 | 70464307.0 | 70632079.0 | bytes |
| container_tasks | available | 50 | 32.34 | 32.0 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
