# DWARF measurement report

Scenario: phase3-runtime-generated-haskell3-node1-malformed-blockfetch
Duration: 1.247990447 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 1 | 4082.4930000000004 | 4082.4930000000004 | 4082.4930000000004 | 4082.4930000000004 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | unavailable | 0 | — | — | — | — | blocks |
  - served_blocks: the node traced no BlockFetch.Server record in this window (namespace not enabled, or silent); a zero would not be a reading
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | unavailable | 0 | — | — | — | — | transactions |
  - mempool_tx_count: Mempool records were traced but none carried a sample
| mempool_bytes | unavailable | 0 | — | — | — | — | bytes |
  - mempool_bytes: Mempool records were traced but none carried a sample
| mempool_sync_duration | available | 1 | 156.62 | 156.62 | 156.62 | 156.62 | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 1 | 788.0 | 788.0 | 788.0 | 788.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 1 | 2.9883174897977227 | 2.9883174897977227 | 2.9883174897977227 | 2.9883174897977227 | % |
| cpu_time_seconds | available | 2 | — | — | — | — | s |
| rss_bytes | available | 2 | 119326720.0 | 119326720.0 | 119443456.0 | 119443456.0 | bytes |
| network_rx_bytes | available | 2 | — | — | — | — | bytes |
| network_tx_bytes | available | 2 | — | — | — | — | bytes |
| disk_read_bytes | available | 2 | — | — | — | — | bytes |
| disk_write_bytes | available | 2 | — | — | — | — | bytes |
| fd_count | available | 2 | 24.0 | 24.0 | 24.0 | 24.0 | fds |
| threads | available | 2 | 12.0 | 12.0 | 12.0 | 12.0 | threads |
| container_memory_bytes | available | 2 | 56130273.0 | 56130273.0 | 56623104.0 | 56623104.0 | bytes |
| container_tasks | available | 2 | 14.0 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| header_validation | available | 0 | — | — | — | — | count |
