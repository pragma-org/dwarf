# DWARF measurement report

Scenario: plutus-onchain-crypto-builtins-differential-amaru-cardano-node
Duration: 89.664204138 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 7 | 1729.0 | 1626.0 | 2156.0 | 2156.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 7 | 467.85714285714283 | 462.0 | 551.0 | 551.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 7 | 2849.5714285714284 | 2832.0 | 3333.0 | 3333.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 8 | 0.75 | 1.0 | 2.0 | 2.0 | tx |
| mempool_size_bytes | available | 8 | 346.0 | 412.5 | 1008.0 | 1008.0 | bytes |
| mempool_terminal_latency | available | 9 | 1198563.7777777778 | 633.0 | 7083900.0 | 7083900.0 | us |
| transfer_validation | available | 6 | 206.0 | 207.5 | 266.0 | 266.0 | us |
| virtual_machine_acquire_arena | available | 11 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 11 | 6.090909090909091 | 5.0 | 14.0 | 14.0 | us |
| virtual_machine_build_program | available | 11 | 30.09090909090909 | 24.0 | 62.0 | 62.0 | us |
| virtual_machine_evaluate | available | 11 | 36.90909090909091 | 31.0 | 84.0 | 84.0 | us |
| block_prepare | available | 7 | 5.142857142857143 | 4.0 | 9.0 | 9.0 | us |
| block_application | available | 7 | 86.57142857142857 | 88.0 | 95.0 | 95.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | available | 3 | 643.0 | 503.0 | 1042.0 | 1042.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 43 | 0.21197656800349166 | 0.0 | 0.9599352879518566 | 1.438648588542733 | % |
| cpu_time_seconds | available | 44 | — | — | — | — | s |
| rss_bytes | available | 44 | 89496762.18181819 | 89903104.0 | 90476544.0 | 91734016.0 | bytes |
| network_rx_bytes | available | 44 | — | — | — | — | bytes |
| network_tx_bytes | available | 44 | — | — | — | — | bytes |
| disk_read_bytes | available | 44 | — | — | — | — | bytes |
| disk_write_bytes | available | 44 | — | — | — | — | bytes |
| fd_count | available | 44 | 28.0 | 28.0 | 28.0 | 28.0 | fds |
| threads | available | 44 | 30.34090909090909 | 30.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 44 | 70093253.8409091 | 70679265.0 | 71879884.0 | 72655831.0 | bytes |
| container_tasks | available | 44 | 32.34090909090909 | 32.0 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
