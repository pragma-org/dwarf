# DWARF measurement report

Scenario: amaru-measurement-e2e-stock-portable
Duration: 13.080081472 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 2 | 28.0 | 28.0 | 35.0 | 35.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 2 | 820.5 | 820.5 | 948.0 | 948.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 2 | 2139.0 | 2139.0 | 2430.0 | 2430.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | unavailable | 0 | — | — | — | — | tx |
| mempool_size_bytes | unavailable | 0 | — | — | — | — | bytes |
| mempool_terminal_latency | unavailable | 0 | — | — | — | — | us |
| transfer_validation | unavailable | 0 | — | — | — | — | us |
  - transfer_validation: no completed stock telemetry span was exported for transaction-validation
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 2 | 4.0 | 4.0 | 5.0 | 5.0 | us |
| block_application | available | 2 | 125.605 | 125.605 | 158.894 | 158.894 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | unavailable | 0 | — | — | — | — | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 7 | 1.5528571428571427 | 1.84 | 2.65 | 2.65 | % |
| cpu_time_seconds | unavailable | 0 | — | — | — | — | s |
  - cpu_time_seconds: at least two monotonic counter samples are required
| rss_bytes | unavailable | 0 | — | — | — | — | bytes |
| network_rx_bytes | available | 0 | — | — | — | — | bytes |
| network_tx_bytes | available | 0 | — | — | — | — | bytes |
| disk_read_bytes | available | 0 | — | — | — | — | bytes |
| disk_write_bytes | available | 0 | — | — | — | — | bytes |
| fd_count | unavailable | 0 | — | — | — | — | fds |
| threads | unavailable | 0 | — | — | — | — | threads |
| container_memory_bytes | available | 7 | 57479939.85714286 | 57514393.0 | 57912852.0 | 57912852.0 | bytes |
| container_tasks | available | 7 | 28.0 | 28.0 | 28.0 | 28.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
| attempt_latency | available | 100 | 100387.74 | 101342.5 | 102212.0 | 102479.0 | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| protocol_decode | available | 108 | 3.014898148148148 | 2.7505 | 5.51 | 7.094 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 108 | 3.441175925925926 | 3.1310000000000002 | 6.502 | 7.755 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | available | 100 | 2.50626 | 2.099 | 5.531 | 6.062 | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | available | 100 | 3.0954099999999998 | 2.8200000000000003 | 5.21 | 7.094 | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | available | 67 | 0.8023731343283582 | 0.651 | 1.923 | 2.865 | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| handler | available | 10 | 21.7977 | 19.4825 | 43.293 | 43.293 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 2 | 2.2245 | 2.2245 | 2.375 | 2.375 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 10 | 0.8 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 10 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | unavailable | 0 | — | — | — | — | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | unavailable | 0 | — | — | — | — | us |
| body_to_terminal | unavailable | 0 | — | — | — | — | us |
| amaru-patched-txsubmission-residence.pending_depth | unavailable | 0 | — | — | — | — | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | unavailable | 0 | — | — | — | — | transactions |
| unacked_depth | unavailable | 0 | — | — | — | — | transactions |
| blocking_residence | unavailable | 0 | — | — | — | — | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
