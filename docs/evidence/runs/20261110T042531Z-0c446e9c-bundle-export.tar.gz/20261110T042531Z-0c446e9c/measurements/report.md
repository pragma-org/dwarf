# DWARF measurement report

Scenario: runtime-substrate-byzantine-blockfetch-example-smoke
Duration: 101.918677695 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 23 | 119109.45513043478 | 3900.034 | 50883.296 | 2511486.54 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | unavailable | 0 | — | — | — | — | transactions |
  - mempool_tx_count: Mempool records were traced but none carried a sample
| mempool_bytes | unavailable | 0 | — | — | — | — | bytes |
  - mempool_bytes: Mempool records were traced but none carried a sample
| mempool_sync_duration | available | 39 | 210.39192307692306 | 169.054 | 828.867 | 958.965 | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 18 | 897.5 | 866.5 | 2906.0 | 2906.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 48 | 1.7847192207187055 | 1.910032106057439 | 2.8629249976196576 | 2.869918695114382 | % |
| cpu_time_seconds | available | 50 | — | — | — | — | s |
| rss_bytes | available | 50 | 117807267.84 | 118456320.0 | 121556992.0 | 121569280.0 | bytes |
| network_rx_bytes | available | 50 | — | — | — | — | bytes |
| network_tx_bytes | available | 50 | — | — | — | — | bytes |
| disk_read_bytes | available | 50 | — | — | — | — | bytes |
| disk_write_bytes | available | 50 | — | — | — | — | bytes |
| fd_count | available | 50 | 24.62 | 24.0 | 27.0 | 27.0 | fds |
| threads | available | 50 | 11.9 | 12.0 | 12.0 | 12.0 | threads |
| container_memory_bytes | available | 50 | 54214943.92 | 54772367.0 | 57818480.0 | 58080624.0 | bytes |
| container_tasks | available | 50 | 13.9 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| header_validation | available | 0 | — | — | — | — | count |
