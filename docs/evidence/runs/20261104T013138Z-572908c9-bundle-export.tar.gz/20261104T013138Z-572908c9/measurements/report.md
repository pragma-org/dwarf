# DWARF measurement report

Scenario: amaru-measurement-workload-stock-portable
Duration: 789.637522463 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 317 | 12339.520504731861 | 90.0 | 6361.0 | 9288.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 317 | 1352.8675078864353 | 874.0 | 3636.0 | 5933.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 317 | 6419.652996845426 | 4185.0 | 13990.0 | 14882.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | available | 7 | 3343.1428571428573 | 1677.0 | 13180.0 | 13180.0 | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 80 | 0.5 | 0.5 | 1.0 | 1.0 | tx |
| mempool_size_bytes | available | 80 | 166.125 | 142.5 | 381.0 | 381.0 | bytes |
| mempool_terminal_latency | available | 80 | 1058258.6125 | 98555.0 | 4389933.0 | 11924766.0 | us |
| transfer_validation | available | 42 | 213.5952380952381 | 194.5 | 367.0 | 410.0 | us |
| virtual_machine_acquire_arena | available | 41 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 41 | 3.2195121951219514 | 3.0 | 5.0 | 6.0 | us |
| virtual_machine_build_program | available | 41 | 28.4390243902439 | 26.0 | 41.0 | 68.0 | us |
| virtual_machine_evaluate | available | 41 | 20.073170731707318 | 18.0 | 33.0 | 39.0 | us |
| block_prepare | available | 325 | 5.587692307692308 | 5.0 | 12.0 | 23.0 | us |
| block_application | available | 310 | 96.50322580645161 | 85.0 | 163.0 | 410.0 | us |
| epoch_transition | available | 4 | 9137.25 | 9359.0 | 11013.0 | 11013.0 | us |
| keepalive_round_trip | available | 15 | 483.3333333333333 | 483.0 | 886.0 | 886.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 314 | 0.3076751592356688 | 0.195 | 0.82 | 1.65 | % |
| cpu_time_seconds | unavailable | 0 | — | — | — | — | s |
  - cpu_time_seconds: at least two monotonic counter samples are required
| rss_bytes | unavailable | 0 | — | — | — | — | bytes |
| network_rx_bytes | available | 0 | — | — | — | — | bytes |
| network_tx_bytes | unavailable | 0 | — | — | — | — | bytes |
  - network_tx_bytes: counter reset or non-positive sample duration
| disk_read_bytes | unavailable | 0 | — | — | — | — | bytes |
  - disk_read_bytes: counter reset or non-positive sample duration
| disk_write_bytes | unavailable | 0 | — | — | — | — | bytes |
  - disk_write_bytes: counter reset or non-positive sample duration
| fd_count | unavailable | 0 | — | — | — | — | fds |
| threads | unavailable | 0 | — | — | — | — | threads |
| container_memory_bytes | available | 314 | 60530107.662420385 | 58337525.5 | 67853352.0 | 68063068.0 | bytes |
| container_tasks | available | 314 | 27.936305732484076 | 28.0 | 28.0 | 29.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
| attempt_latency | available | 120 | 720363.9205000001 | 101257.0 | 3088580.73 | 6408725.206 | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | available | 20 | 3821005.0730000003 | 3040561.7315 | 6408725.206 | 13424953.569 | us |
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| header_validation | available | 0 | — | — | — | — | count |
