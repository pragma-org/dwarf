# DWARF measurement report

Scenario: ledger-submit-multiasset-compact-boundary-differential-amaru-cardano-node
Duration: 102.567310166 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 4 | 1807.25 | 1674.5 | 2363.0 | 2363.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 4 | 3033.25 | 3195.5 | 5205.0 | 5205.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 4 | 8500.5 | 9365.0 | 12740.0 | 12740.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 3 | 0.6666666666666666 | 1.0 | 1.0 | 1.0 | tx |
| mempool_size_bytes | available | 3 | 7843.333333333333 | 11761.0 | 11769.0 | 11769.0 | bytes |
| mempool_terminal_latency | available | 4 | 1983545.25 | 1639.0 | 7929741.0 | 7929741.0 | us |
| transfer_validation | available | 3 | 1102.3333333333333 | 1442.0 | 1650.0 | 1650.0 | us |
| virtual_machine_acquire_arena | unavailable | 0 | — | — | — | — | us |
| virtual_machine_decode_script | unavailable | 0 | — | — | — | — | us |
| virtual_machine_build_program | unavailable | 0 | — | — | — | — | us |
| virtual_machine_evaluate | unavailable | 0 | — | — | — | — | us |
| block_prepare | available | 4 | 9.25 | 9.5 | 14.0 | 14.0 | us |
| block_application | available | 4 | 134.25 | 129.0 | 181.0 | 181.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | available | 4 | 650.5 | 648.5 | 882.0 | 882.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 50 | 0.23992566503073134 | 0.0 | 0.9596457304360442 | 1.4408575059389073 | % |
| cpu_time_seconds | available | 51 | — | — | — | — | s |
| rss_bytes | available | 51 | 88369031.52941176 | 88023040.0 | 89567232.0 | 89571328.0 | bytes |
| network_rx_bytes | available | 51 | — | — | — | — | bytes |
| network_tx_bytes | available | 51 | — | — | — | — | bytes |
| disk_read_bytes | available | 51 | — | — | — | — | bytes |
| disk_write_bytes | available | 51 | — | — | — | — | bytes |
| fd_count | available | 51 | 28.0 | 28.0 | 28.0 | 28.0 | fds |
| threads | available | 51 | 30.49019607843137 | 30.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 51 | 69624212.2745098 | 70432849.0 | 71166853.0 | 71418511.0 | bytes |
| container_tasks | available | 51 | 32.490196078431374 | 32.0 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
