# DWARF measurement report

Scenario: phase3-runtime-profile-a-copied-state-postremediation-blockfetch-primitive
Duration: 223.986324435 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 58 | 62922.44812068966 | 4071.873 | 6043.167 | 3405264.825 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | unavailable | 0 | — | — | — | — | transactions |
  - mempool_tx_count: Mempool records were traced but none carried a sample
| mempool_bytes | unavailable | 0 | — | — | — | — | bytes |
  - mempool_bytes: Mempool records were traced but none carried a sample
| mempool_sync_duration | available | 92 | 309.6255217391304 | 183.4915 | 395.777 | 8023.6230000000005 | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 44 | 689.3863636363636 | 664.0 | 1047.0 | 1168.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 104 | 1.7105177557082112 | 1.9100039292213535 | 2.390916143734746 | 2.3936271768476916 | % |
| cpu_time_seconds | available | 107 | — | — | — | — | s |
| rss_bytes | available | 107 | 124913032.37383178 | 127049728.0 | 127447040.0 | 127447040.0 | bytes |
| network_rx_bytes | available | 108 | — | — | — | — | bytes |
| network_tx_bytes | available | 108 | — | — | — | — | bytes |
| disk_read_bytes | available | 108 | — | — | — | — | bytes |
| disk_write_bytes | available | 108 | — | — | — | — | bytes |
| fd_count | available | 107 | 24.009345794392523 | 24.0 | 24.0 | 24.0 | fds |
| threads | available | 107 | 11.878504672897197 | 12.0 | 12.0 | 12.0 | threads |
| container_memory_bytes | available | 108 | 61491020.44444445 | 63575162.0 | 64088965.0 | 64109936.0 | bytes |
| container_tasks | available | 108 | 13.777777777777779 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| header_validation | available | 0 | — | — | — | — | count |
