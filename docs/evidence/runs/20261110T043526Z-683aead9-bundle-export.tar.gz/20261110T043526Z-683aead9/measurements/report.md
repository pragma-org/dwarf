# DWARF measurement report

Scenario: runtime-substrate-snapshot-mid-run-corrupt-recovery-example-smoke
Duration: 95.676325794 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 19 | 1199604.049473684 | 4072.536 | 10883328.633 | 10883328.633 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | unavailable | 0 | — | — | — | — | transactions |
  - mempool_tx_count: Mempool records were traced but none carried a sample
| mempool_bytes | unavailable | 0 | — | — | — | — | bytes |
  - mempool_bytes: Mempool records were traced but none carried a sample
| mempool_sync_duration | unavailable | 0 | — | — | — | — | us |
  - mempool_sync_duration: Mempool records were traced but none carried a sample
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 12 | 452.75 | 327.5 | 961.0 | 961.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 44 | 2.383161949096833 | 1.9109647800033367 | 2.391290503532088 | 29.678807773689275 | % |
| cpu_time_seconds | available | 47 | — | — | — | — | s |
| rss_bytes | available | 47 | 116417557.78723404 | 117354496.0 | 117432320.0 | 117567488.0 | bytes |
| network_rx_bytes | available | 47 | — | — | — | — | bytes |
| network_tx_bytes | available | 47 | — | — | — | — | bytes |
| disk_read_bytes | available | 47 | — | — | — | — | bytes |
| disk_write_bytes | available | 47 | — | — | — | — | bytes |
| fd_count | available | 47 | 23.53191489361702 | 24.0 | 24.0 | 24.0 | fds |
| threads | available | 47 | 11.574468085106384 | 12.0 | 12.0 | 12.0 | threads |
| container_memory_bytes | available | 47 | 53196424.02127659 | 54924410.0 | 55207526.0 | 55249469.0 | bytes |
| container_tasks | available | 47 | 13.382978723404255 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
| header_validation | available | 0 | — | — | — | — | count |
