Dwarf Bundle Export

This archive contains the run bundle directory '20261110T043526Z-683aead9/'.

What is included:
- The exported run bundle directory with its existing artifacts
- The in-bundle promotion, dedupe, and signature records when present

How to verify the extracted bundle with an unmodified CLI:
1. Extract this tarball into a parent directory.
2. Run: cardano-profile bundle verify 20261110T043526Z-683aead9 --runs-dir <extracted-parent>/runs-or-parent

How to verify the export tarball itself:
- Use the sibling export signature artifact produced next to this tarball.
- The forthcoming bundle import surface will automate that check.

