# DWARF measurement report

Scenario: ledger-submit-uplc-deep-delay-stack-safety-differential-amaru-cardano-node
Duration: 105.301822382 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| header_slot_start_to_reception | unavailable | 0 | — | — | — | — | us |
  - header_slot_start_to_reception: the pinned Amaru release exports header receipt in the global epoch and slot start in chain-relative time; mixed clock domains cannot produce an arrival latency
| header_slot_start_to_reception_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_fetch_request | available | 5 | 28.6 | 24.0 | 40.0 | 40.0 | us |
| header_reception_to_fetch_request_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_fetch | available | 5 | 1551.6 | 1334.0 | 2904.0 | 2904.0 | us |
| block_fetch_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_reception_to_terminal_forward | available | 5 | 4135.4 | 3577.0 | 7971.0 | 7971.0 | us |
| header_reception_to_terminal_forward_by_outcome | unavailable | 0 | — | — | — | — | — |
| fork_switch | unavailable | 0 | — | — | — | — | us |
| fork_switch_by_outcome | unavailable | 0 | — | — | — | — | — |
| mempool_received | available | 0 | — | — | — | — | events |
| mempool_accepted | available | 0 | — | — | — | — | events |
| mempool_rejected | available | 0 | — | — | — | — | events |
| mempool_evicted | available | 0 | — | — | — | — | events |
| mempool_tx_count | available | 4 | 0.5 | 0.5 | 1.0 | 1.0 | tx |
| mempool_size_bytes | available | 4 | 3692.25 | 191.5 | 14386.0 | 14386.0 | bytes |
| mempool_terminal_latency | available | 4 | 6700095.5 | 2412131.5 | 21974831.0 | 21974831.0 | us |
| transfer_validation | available | 4 | 1469.75 | 789.5 | 4049.0 | 4049.0 | us |
| virtual_machine_acquire_arena | available | 5 | 0.0 | 0.0 | 0.0 | 0.0 | us |
| virtual_machine_decode_script | available | 5 | 1717.6 | 5.0 | 4848.0 | 4848.0 | us |
| virtual_machine_build_program | available | 5 | 57.8 | 38.0 | 142.0 | 142.0 | us |
| virtual_machine_evaluate | available | 5 | 20.4 | 17.0 | 32.0 | 32.0 | us |
| block_prepare | available | 5 | 10.6 | 9.0 | 20.0 | 20.0 | us |
| block_application | available | 5 | 119.8 | 113.0 | 156.0 | 156.0 | us |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
  - epoch_transition: no completed stock telemetry span was exported for epoch-transition
| keepalive_round_trip | available | 4 | 446.5 | 460.5 | 528.0 | 528.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| cpu_percent | available | 51 | 0.2260920143948731 | 0.0 | 0.9559940686774505 | 0.960245018941585 | % |
| cpu_time_seconds | available | 52 | — | — | — | — | s |
| rss_bytes | available | 52 | 93993353.84615384 | 94494720.0 | 95477760.0 | 95678464.0 | bytes |
| network_rx_bytes | available | 52 | — | — | — | — | bytes |
| network_tx_bytes | available | 52 | — | — | — | — | bytes |
| disk_read_bytes | available | 52 | — | — | — | — | bytes |
| disk_write_bytes | available | 52 | — | — | — | — | bytes |
| fd_count | available | 52 | 28.0 | 28.0 | 28.0 | 28.0 | fds |
| threads | available | 52 | 30.307692307692307 | 30.0 | 31.0 | 31.0 | threads |
| container_memory_bytes | available | 52 | 111415232.51923077 | 109785907.0 | 134742016.0 | 138516889.0 | bytes |
| container_tasks | available | 52 | 32.34615384615385 | 32.0 | 33.0 | 33.0 | tasks |
| restart_readiness | unavailable | 0 | — | — | — | — | s |
  - restart_readiness: listener, live chain progress, and required peer-role gates are all required
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
  - backlog: no backlog samples were retained
| attempt_latency | unavailable | 0 | — | — | — | — | us |
| submit_to_protocol_response | unavailable | 0 | — | — | — | — | us |
  - submit_to_protocol_response: no authoritative correlated boundary was retained for this stage
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | unavailable | 0 | — | — | — | — | us |
  - submit_to_block_inclusion: no authoritative correlated boundary was retained for this stage
| submit_to_chain_adoption | unavailable | 0 | — | — | — | — | us |
  - submit_to_chain_adoption: no authoritative correlated boundary was retained for this stage
