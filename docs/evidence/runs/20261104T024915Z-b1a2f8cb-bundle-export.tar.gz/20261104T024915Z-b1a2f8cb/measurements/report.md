# DWARF measurement report

Scenario: cardano-measurement-workload-stock-portable
Duration: 323.515567159 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 82 | 4757.074512195122 | 4468.1395 | 5729.732 | 12619.237000000001 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | available | 80 | 0.5 | 0.5 | 1.0 | 1.0 | transactions |
| mempool_bytes | available | 80 | 166.75 | 143.0 | 385.0 | 385.0 | bytes |
| mempool_sync_duration | unavailable | 0 | — | — | — | — | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 46 | 644.3695652173913 | 569.5 | 1412.0 | 1563.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 130 | 3.2223846153846156 | 2.5999999999999996 | 5.92 | 12.37 | % |
| cpu_time_seconds | unavailable | 0 | — | — | — | — | s |
  - cpu_time_seconds: at least two monotonic counter samples are required
| rss_bytes | unavailable | 0 | — | — | — | — | bytes |
| network_rx_bytes | available | 0 | — | — | — | — | bytes |
| network_tx_bytes | available | 0 | — | — | — | — | bytes |
| disk_read_bytes | unavailable | 0 | — | — | — | — | bytes |
  - disk_read_bytes: counter reset or non-positive sample duration
| disk_write_bytes | unavailable | 0 | — | — | — | — | bytes |
  - disk_write_bytes: counter reset or non-positive sample duration
| fd_count | unavailable | 0 | — | — | — | — | fds |
| threads | unavailable | 0 | — | — | — | — | threads |
| container_memory_bytes | available | 130 | 71433271.62307692 | 72309800.0 | 77007421.0 | 77290536.0 | bytes |
| container_tasks | available | 130 | 13.915384615384616 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
| attempt_latency | available | 120 | 572005.1393 | 190.0 | 3490193.687 | 9566367.474 | us |
| submit_to_protocol_response | available | 20 | 337335.49935 | 334230.55299999996 | 356354.951 | 394101.311 | us |
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | available | 20 | 3430750.1358000003 | 2690425.4715 | 9566367.474 | 10415809.866 | us |
| submit_to_chain_adoption | available | 20 | 3430750.1358000003 | 2690425.4715 | 9566367.474 | 10415809.866 | us |
| protocol_receive_decode | available | 2777 | 832270.6887648541 | 389.776 | 5699436.295 | 10199386.641 | us |
| protocol_receive_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_application | available | 337 | 71.97318694362018 | 35.889 | 349.469 | 460.652 | us |
| block_application_by_outcome | unavailable | 0 | — | — | — | — | — |
| epoch_transition | available | 16 | 121.352375 | 93.4385 | 325.252 | 325.252 | us |
| epoch_transition_by_outcome | unavailable | 0 | — | — | — | — | — |
| plutus_vm | available | 40 | 58.8612 | 59.102999999999994 | 74.072 | 91.805 | us |
| plutus_vm_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_validation | available | 0 | — | — | — | — | count |
