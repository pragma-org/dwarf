# DWARF measurement report

Scenario: cardano-amaru-miniprotocol-security-local
Duration: 4.6254e-05 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| keepalive_round_trip | available | 1 | 37.0 | 37.0 | 37.0 | 37.0 | us |
| peer_connected | available | 0 | — | — | — | — | events |
| mux_failed | available | 0 | — | — | — | — | events |
| chain_tip_updates | available | 0 | — | — | — | — | events |
| header_validation | available | 0 | — | — | — | — | count |
| protocol_decode | available | 424 | 0.08615566037735849 | 0.06 | 0.12 | 0.12 | us |
| protocol_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| protocol_total | available | 424 | 0.1521014150943396 | 0.12 | 0.238 | 0.298 | us |
| protocol_total_by_state_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_ingress | available | 83 | 0.11636144578313252 | 0.119 | 0.12 | 0.12 | us |
| handshake_ingress_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_decode | available | 83 | 0.10910843373493975 | 0.119 | 0.12 | 0.12 | us |
| handshake_decode_by_decode_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_state_by_outcome | unavailable | 0 | — | — | — | — | — |
| handshake_negotiation | available | 83 | 0.06466265060240964 | 0.06 | 0.119 | 0.12 | us |
| handshake_negotiation_by_outcome | unavailable | 0 | — | — | — | — | — |
| amaru-patched-header-validation.header_validation | available | 40 | 165.473025 | 34.4515 | 251.174 | 4266.5 | us |
| header_validation_by_outcome | unavailable | 0 | — | — | — | — | — |
| unavailable_prerequisites | unavailable | 0 | — | — | — | — | us |
| unavailable_by_error_kind | unavailable | 0 | — | — | — | — | — |
| handler | available | 97 | 7.738845360824742 | 3.815 | 29.326 | 215.59 | us |
| handler_by_outcome | unavailable | 0 | — | — | — | — | — |
| block_decode | available | 40 | 0.24892499999999998 | 0.238 | 0.417 | 0.537 | us |
| block_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| queue_residence | unavailable | 0 | — | — | — | — | us |
| queue_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
| inflight_depth | available | 97 | 0.845360824742268 | 1.0 | 1.0 | 1.0 | requests |
| pending_depth | available | 97 | 0.0 | 0.0 | 0.0 | 0.0 | requests |
| advertised_to_terminal | unavailable | 0 | — | — | — | — | us |
| advertised_to_terminal_by_outcome | unavailable | 0 | — | — | — | — | — |
| advertised_to_body | unavailable | 0 | — | — | — | — | us |
| body_to_terminal | unavailable | 0 | — | — | — | — | us |
| amaru-patched-txsubmission-residence.pending_depth | unavailable | 0 | — | — | — | — | transactions |
| amaru-patched-txsubmission-residence.inflight_depth | unavailable | 0 | — | — | — | — | transactions |
| unacked_depth | unavailable | 0 | — | — | — | — | transactions |
| blocking_residence | unavailable | 0 | — | — | — | — | us |
| blocking_residence_by_outcome | unavailable | 0 | — | — | — | — | — |
