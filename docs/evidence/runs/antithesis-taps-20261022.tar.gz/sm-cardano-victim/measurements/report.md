# DWARF measurement report

Scenario: cardano-amaru-miniprotocol-security-local
Duration: 7.85e-05 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| keepalive_rtt | unavailable | 0 | — | — | — | — | us |
| protocol_events | available | 0 | — | — | — | — | events |
| header_validation | available | 0 | — | — | — | — | count |
| protocol_receive_decode | available | 926 | 36644.64096652268 | 1.61 | 325.858 | 1000306.665 | us |
| protocol_receive_decode_by_outcome | unavailable | 0 | — | — | — | — | — |
| cardano-patched-header-validation.header_validation | available | 47 | 51.88897872340426 | 24.26 | 267.148 | 449.121 | us |
| header_validation_by_outcome | unavailable | 0 | — | — | — | — | — |
| header_prerequisite_unavailable | unavailable | 0 | — | — | — | — | us |
| queue_residence_lower_bound | available | 7 | 0.0 | 0.0 | 0.0 | 0.0 | microseconds |
| queue_residence_upper_bound | available | 7 | 228.68599999999998 | 14.544 | 670.314 | 670.314 | microseconds |
| handler_service | available | 7 | 2.3754285714285714 | 2.384 | 2.384 | 2.384 | microseconds |
| pending_range_depth | available | 14 | 0.5 | 0.5 | 1.0 | 1.0 | ranges |
| request_to_body_lower_bound | unavailable | 0 | — | — | — | — | microseconds |
| request_to_body_upper_bound | unavailable | 0 | — | — | — | — | microseconds |
| body_to_terminal_lower_bound | unavailable | 0 | — | — | — | — | microseconds |
| body_to_terminal_upper_bound | unavailable | 0 | — | — | — | — | microseconds |
| request_to_terminal_lower_bound | unavailable | 0 | — | — | — | — | microseconds |
| request_to_terminal_upper_bound | unavailable | 0 | — | — | — | — | microseconds |
| pending_body_depth | unavailable | 0 | — | — | — | — | transactions |
| inflight_body_depth | unavailable | 0 | — | — | — | — | transactions |
| block_application | available | 28 | 3.1866785714285717 | 3.278 | 3.457 | 4.351 | us |
| block_application_by_outcome | unavailable | 0 | — | — | — | — | — |
| epoch_transition | unavailable | 0 | — | — | — | — | us |
| epoch_transition_by_outcome | unavailable | 0 | — | — | — | — | — |
| plutus_vm | unavailable | 0 | — | — | — | — | us |
| plutus_vm_by_outcome | unavailable | 0 | — | — | — | — | — |
