# DWARF measurement report

Scenario: cardano-measurement-workload-stock-portable
Duration: 307.951569542 seconds

| Metric | Status | Samples | Mean | Median | p95 | p99 | Unit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| chain_events | available | 0 | — | — | — | — | events |
| adopted_blocks | available | 0 | — | — | — | — | blocks |
| rollbacks | available | 0 | — | — | — | — | events |
| blockfetch_duration | available | 85 | 4509.123517647059 | 4310.139 | 5790.456 | 12991.487 | us |
| blockfetch_bytes | available | 0 | — | — | — | — | bytes |
| served_blocks | available | 0 | — | — | — | — | blocks |
| handler_queue_residence | unavailable | 0 | — | — | — | — | us |
  - handler_queue_residence: stock Cardano-node does not emit the audited internal handler queue boundary
| mempool_accepted | available | 0 | — | — | — | — | transactions |
| mempool_rejected | available | 0 | — | — | — | — | transactions |
| mempool_tx_count | available | 80 | 0.5 | 0.5 | 1.0 | 1.0 | transactions |
| mempool_bytes | available | 80 | 166.75 | 143.0 | 385.0 | 385.0 | bytes |
| mempool_sync_duration | unavailable | 0 | — | — | — | — | us |
| txsubmission_residence | unavailable | 0 | — | — | — | — | us |
  - txsubmission_residence: stock Cardano-node does not emit a continuous request-to-mempool residence interval
| cardano-stock-ledger-block-epoch.adopted_blocks | available | 0 | — | — | — | — | blocks |
| ledger_samples | available | 0 | — | — | — | — | events |
| epoch_transition_duration | unavailable | 0 | — | — | — | — | us |
  - epoch_transition_duration: stock traces do not expose one authoritative epoch-transition interval
| transaction_outcomes | available | 0 | — | — | — | — | transactions |
| plutus_vm_duration | unavailable | 0 | — | — | — | — | us |
  - plutus_vm_duration: stock Cardano-node does not expose authoritative UPLC wall-clock stage timing
| keepalive_rtt | available | 46 | 480.2608695652174 | 406.5 | 1040.0 | 1173.0 | us |
| protocol_events | available | 0 | — | — | — | — | events |
| cpu_percent | available | 124 | 2.923225806451613 | 2.375 | 5.88 | 12.38 | % |
| cpu_time_seconds | unavailable | 0 | — | — | — | — | s |
  - cpu_time_seconds: at least two monotonic counter samples are required
| rss_bytes | unavailable | 0 | — | — | — | — | bytes |
| network_rx_bytes | unavailable | 0 | — | — | — | — | bytes |
  - network_rx_bytes: counter reset or non-positive sample duration
| network_tx_bytes | unavailable | 0 | — | — | — | — | bytes |
  - network_tx_bytes: counter reset or non-positive sample duration
| disk_read_bytes | available | 0 | — | — | — | — | bytes |
| disk_write_bytes | available | 0 | — | — | — | — | bytes |
| fd_count | unavailable | 0 | — | — | — | — | fds |
| threads | unavailable | 0 | — | — | — | — | threads |
| container_memory_bytes | available | 124 | 68568498.14516129 | 70081576.5 | 72876032.0 | 72897003.0 | bytes |
| container_tasks | available | 124 | 13.991935483870968 | 14.0 | 14.0 | 14.0 | tasks |
| restart_readiness | available | 0 | — | — | — | — | s |
| sync_speed | available | 0 | — | — | — | — | blocks/s |
| offered_operations | available | 0 | — | — | — | — | operations/s |
| successful_operations | available | 0 | — | — | — | — | operations |
| rejected_operations | available | 0 | — | — | — | — | operations |
| timed_out_operations | available | 0 | — | — | — | — | operations |
| offered_bytes | available | 0 | — | — | — | — | bytes |
| successful_operations_per_second | available | 0 | — | — | — | — | operations/s |
| rejected_operations_per_second | available | 0 | — | — | — | — | operations/s |
| offered_bytes_per_second | available | 0 | — | — | — | — | bytes/s |
| batches_per_second | available | 0 | — | — | — | — | batches/s |
| backlog | unavailable | 0 | — | — | — | — | — |
| attempt_latency | available | 120 | 566269.7357 | 167.0 | 3628491.921 | 7087793.072 | us |
| submit_to_protocol_response | available | 20 | 336676.4394 | 331531.1665 | 360148.963 | 400329.289 | us |
| submit_to_mempool_visibility | unavailable | 0 | — | — | — | — | us |
  - submit_to_mempool_visibility: no authoritative correlated boundary was retained for this stage
| submit_to_block_inclusion | available | 20 | 3396440.4141999995 | 2691039.3945 | 7087793.072 | 10450396.951 | us |
| submit_to_chain_adoption | available | 20 | 3396440.4141999995 | 2691039.3945 | 7087793.072 | 10450396.951 | us |
| header_validation | available | 0 | — | — | — | — | count |
