Dwarf Bundle Export

This archive contains the run bundle directory 'external-antithesis-3a5587c84bf7bf0bc76312d9/'.

Public export: operator namespace paths were redacted from the JSON artifacts
(replaced by <operator-namespace>); the retained run-plan stamp does not verify on this copy.

What is included:
- The exported run bundle directory with its existing artifacts
- The in-bundle promotion, dedupe, and signature records when present

How to verify the extracted bundle with an unmodified CLI:
1. Extract this tarball into a parent directory.
2. Run: cardano-profile bundle verify external-antithesis-3a5587c84bf7bf0bc76312d9 --runs-dir <extracted-parent>/runs-or-parent

How to verify the export tarball itself:
- Use the sibling export signature artifact produced next to this tarball.
- The forthcoming bundle import surface will automate that check.

